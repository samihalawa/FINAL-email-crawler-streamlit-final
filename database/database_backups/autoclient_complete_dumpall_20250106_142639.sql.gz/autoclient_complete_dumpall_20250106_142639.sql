--
-- PostgreSQL database cluster dump
--

-- Started on 2025-01-06 14:26:40 CET

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--





--
-- Drop roles
--

DROP ROLE IF EXISTS anon;
DROP ROLE IF EXISTS authenticated;
DROP ROLE IF EXISTS authenticator;
DROP ROLE IF EXISTS dashboard_user;
DROP ROLE IF EXISTS pgbouncer;
DROP ROLE IF EXISTS pgsodium_keyholder;
DROP ROLE IF EXISTS pgsodium_keyiduser;
DROP ROLE IF EXISTS pgsodium_keymaker;
DROP ROLE IF EXISTS postgres;
DROP ROLE IF EXISTS service_role;
DROP ROLE IF EXISTS supabase_admin;
DROP ROLE IF EXISTS supabase_auth_admin;
DROP ROLE IF EXISTS supabase_functions_admin;
DROP ROLE IF EXISTS supabase_read_only_user;
DROP ROLE IF EXISTS supabase_realtime_admin;
DROP ROLE IF EXISTS supabase_replication_admin;
DROP ROLE IF EXISTS supabase_storage_admin;


--
-- Roles
--

CREATE ROLE anon;
ALTER ROLE anon WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE authenticated;
ALTER ROLE authenticated WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE authenticator;
ALTER ROLE authenticator WITH NOSUPERUSER NOINHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:FIq24BtZhniAyMz0+APzWw==$sJTWq1g7NYs1bbC+x52m7ipZkRX39y111Ps2+sAJnNk=:pZvSdRLP2uimLx8fJFdo0SXgKsArxnvjgKP714MEQN4=';
CREATE ROLE dashboard_user;
ALTER ROLE dashboard_user WITH NOSUPERUSER INHERIT CREATEROLE CREATEDB NOLOGIN REPLICATION NOBYPASSRLS;
CREATE ROLE pgbouncer;
ALTER ROLE pgbouncer WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:IqobRtvqX+uV43tUUHq+ow==$vP5vTU3vVM8bR5W6b8lG8FlT6sIr8Xrmx7uJ7EavK8k=:EIxv2qWL1WcHOxWs0oM5co8PsiBvwBzdSl5/xd0EnAo=';
CREATE ROLE pgsodium_keyholder;
ALTER ROLE pgsodium_keyholder WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE pgsodium_keyiduser;
ALTER ROLE pgsodium_keyiduser WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE pgsodium_keymaker;
ALTER ROLE pgsodium_keymaker WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE postgres;
ALTER ROLE postgres WITH NOSUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:jVWZMCWXufUpAz+guoMAhA==$FlubMwYDO8+ctUZNvNVE02N2bzYGK6SoS6RgsutF6zM=:HXj1g14JFeJSvMpvM6aNVW92DQIVGFQhtoaaQRpEZHM=';
CREATE ROLE service_role;
ALTER ROLE service_role WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION BYPASSRLS;
CREATE ROLE supabase_admin;
ALTER ROLE supabase_admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:R8rT3bAkF+toDwWhrKfw3g==$til2u76FEufb+Qs5VE4tN6bouofyCxfDKMFCHhpHgZs=:NHDJ/PTjC0ecEzB9wNXuWYs51l/IKV4SfE9FyXYL1a4=';
CREATE ROLE supabase_auth_admin;
ALTER ROLE supabase_auth_admin WITH NOSUPERUSER NOINHERIT CREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:Ei7uIA27SUz0JyBskBhF2A==$qsBaFzdQSJYtYzI6z9n3iVs2/BXsR7ei2soXicvHEXI=:rip2NeY7kS3HgOkvN6g9449G/Smr5Z5/578g7pLoR/I=';
CREATE ROLE supabase_functions_admin;
ALTER ROLE supabase_functions_admin WITH NOSUPERUSER NOINHERIT CREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE supabase_read_only_user;
ALTER ROLE supabase_read_only_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:GQDEqYX5yQ9YZL0csAcWWA==$XPcxFf2G3WoSGRtnuVySJeETXE2bB6jHyZoaUjqgm4w=:9IjK+WUvk10h4APOa0XbUmdDqg4s96oNK58G8vH7yi8=';
CREATE ROLE supabase_realtime_admin;
ALTER ROLE supabase_realtime_admin WITH NOSUPERUSER NOINHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE supabase_replication_admin;
ALTER ROLE supabase_replication_admin WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN REPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:UWFaGPhw3YW1ctQj/YdgeA==$+S4y3ch7Jv+s0NvVFwM/EYQBpEcK3OxtGMxWYQs4Mf8=:IOjlH0G/JvgRKIatUggAF94v5GcXowmeH9UBAi3ZvX0=';
CREATE ROLE supabase_storage_admin;
ALTER ROLE supabase_storage_admin WITH NOSUPERUSER NOINHERIT CREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:NLhSyeZ8Ql9g4/THxwZiDw==$v5kZvX7lgyby2QQ+dBesCCQXgX4teCOxb7ok9/sGJEY=:4dO3k9S8yCzhzroT3Nge6WI+W7VpomNZJXOIfNropvg=';

--
-- User Configurations
--

--
-- User Config "anon"
--

ALTER ROLE anon SET statement_timeout TO '3s';

--
-- User Config "authenticated"
--

ALTER ROLE authenticated SET statement_timeout TO '8s';

--
-- User Config "authenticator"
--

ALTER ROLE authenticator SET session_preload_libraries TO 'safeupdate';
ALTER ROLE authenticator SET statement_timeout TO '8s';
ALTER ROLE authenticator SET lock_timeout TO '8s';

--
-- User Config "postgres"
--

ALTER ROLE postgres SET search_path TO E'\\$user', 'public', 'extensions';

--
-- User Config "supabase_admin"
--

ALTER ROLE supabase_admin SET search_path TO '$user', 'public', 'auth', 'extensions';

--
-- User Config "supabase_auth_admin"
--

ALTER ROLE supabase_auth_admin SET search_path TO 'auth';
ALTER ROLE supabase_auth_admin SET idle_in_transaction_session_timeout TO '60000';

--
-- User Config "supabase_functions_admin"
--

ALTER ROLE supabase_functions_admin SET search_path TO 'supabase_functions';

--
-- User Config "supabase_storage_admin"
--

ALTER ROLE supabase_storage_admin SET search_path TO 'storage';


--
-- Role memberships
--

GRANT anon TO authenticator GRANTED BY postgres;
GRANT anon TO postgres GRANTED BY supabase_admin;
GRANT authenticated TO authenticator GRANTED BY postgres;
GRANT authenticated TO postgres GRANTED BY supabase_admin;
GRANT authenticator TO supabase_storage_admin GRANTED BY supabase_admin;
GRANT pg_monitor TO postgres GRANTED BY supabase_admin;
GRANT pg_read_all_data TO postgres GRANTED BY supabase_admin;
GRANT pg_read_all_data TO supabase_read_only_user GRANTED BY postgres;
GRANT pg_signal_backend TO postgres GRANTED BY supabase_admin;
GRANT pgsodium_keyholder TO pgsodium_keymaker GRANTED BY supabase_admin;
GRANT pgsodium_keyholder TO postgres WITH ADMIN OPTION GRANTED BY supabase_admin;
GRANT pgsodium_keyholder TO service_role GRANTED BY supabase_admin;
GRANT pgsodium_keyiduser TO pgsodium_keyholder GRANTED BY supabase_admin;
GRANT pgsodium_keyiduser TO pgsodium_keymaker GRANTED BY supabase_admin;
GRANT pgsodium_keyiduser TO postgres WITH ADMIN OPTION GRANTED BY supabase_admin;
GRANT pgsodium_keymaker TO postgres WITH ADMIN OPTION GRANTED BY supabase_admin;
GRANT service_role TO authenticator GRANTED BY postgres;
GRANT service_role TO postgres GRANTED BY supabase_admin;
GRANT supabase_auth_admin TO postgres GRANTED BY supabase_admin;
GRANT supabase_functions_admin TO postgres GRANTED BY supabase_admin;
GRANT supabase_realtime_admin TO postgres GRANTED BY supabase_admin;
GRANT supabase_storage_admin TO postgres GRANTED BY supabase_admin;






--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 15.10 (Homebrew)

-- Started on 2025-01-06 14:26:42 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- TOC entry 3341 (class 1262 OID 28891)
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3343 (class 0 OID 0)
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3342 (class 0 OID 0)
-- Dependencies: 3341
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


-- Completed on 2025-01-06 14:26:46 CET

--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 15.10 (Homebrew)

-- Started on 2025-01-06 14:26:46 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- TOC entry 4503 (class 1262 OID 28892)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 18 (class 2615 OID 16400)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- TOC entry 10 (class 3079 OID 176268)
-- Name: pg_cron; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;


--
-- TOC entry 4506 (class 0 OID 0)
-- Dependencies: 10
-- Name: EXTENSION pg_cron; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_cron IS 'Job scheduler for PostgreSQL';


--
-- TOC entry 21 (class 2615 OID 16401)
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- TOC entry 25 (class 2615 OID 16402)
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- TOC entry 24 (class 2615 OID 16403)
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- TOC entry 9 (class 3079 OID 16404)
-- Name: pg_net; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;


--
-- TOC entry 4509 (class 0 OID 0)
-- Dependencies: 9
-- Name: EXTENSION pg_net; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_net IS 'Async HTTP';


--
-- TOC entry 14 (class 2615 OID 16406)
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- TOC entry 27 (class 2615 OID 16407)
-- Name: pgsodium; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA pgsodium;


ALTER SCHEMA pgsodium OWNER TO supabase_admin;

--
-- TOC entry 2 (class 3079 OID 16408)
-- Name: pgsodium; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgsodium WITH SCHEMA pgsodium;


--
-- TOC entry 4510 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pgsodium; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgsodium IS 'Pgsodium is a modern cryptography library for Postgres.';


--
-- TOC entry 20 (class 2615 OID 181144)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 4511 (class 0 OID 0)
-- Dependencies: 20
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 17 (class 2615 OID 16410)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- TOC entry 15 (class 2615 OID 16411)
-- Name: schemauser; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA schemauser;


ALTER SCHEMA schemauser OWNER TO postgres;

--
-- TOC entry 19 (class 2615 OID 16412)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- TOC entry 22 (class 2615 OID 16413)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA supabase_functions;


ALTER SCHEMA supabase_functions OWNER TO supabase_admin;

--
-- TOC entry 16 (class 2615 OID 16414)
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- TOC entry 23 (class 2615 OID 16415)
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- TOC entry 8 (class 3079 OID 176226)
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- TOC entry 4516 (class 0 OID 0)
-- Dependencies: 8
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- TOC entry 3 (class 3079 OID 16416)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- TOC entry 4517 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 4 (class 3079 OID 16417)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- TOC entry 4518 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 5 (class 3079 OID 16418)
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgjwt WITH SCHEMA extensions;


--
-- TOC entry 4519 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION pgjwt; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgjwt IS 'JSON Web Token API for Postgresql';


--
-- TOC entry 6 (class 3079 OID 16419)
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- TOC entry 4520 (class 0 OID 0)
-- Dependencies: 6
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- TOC entry 7 (class 3079 OID 16420)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- TOC entry 4521 (class 0 OID 0)
-- Dependencies: 7
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1217 (class 1247 OID 29372)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- TOC entry 1220 (class 1247 OID 29380)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- TOC entry 1223 (class 1247 OID 29386)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- TOC entry 1226 (class 1247 OID 29392)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1229 (class 1247 OID 29398)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1269 (class 1247 OID 29412)
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- TOC entry 1272 (class 1247 OID 29424)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- TOC entry 1275 (class 1247 OID 29441)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- TOC entry 1278 (class 1247 OID 29444)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- TOC entry 1281 (class 1247 OID 29447)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- TOC entry 526 (class 1255 OID 16422)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- TOC entry 4522 (class 0 OID 0)
-- Dependencies: 526
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 527 (class 1255 OID 16423)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- TOC entry 528 (class 1255 OID 16424)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- TOC entry 4525 (class 0 OID 0)
-- Dependencies: 528
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 529 (class 1255 OID 16425)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- TOC entry 4527 (class 0 OID 0)
-- Dependencies: 529
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 545 (class 1255 OID 16441)
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO postgres;

--
-- TOC entry 4551 (class 0 OID 0)
-- Dependencies: 545
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- TOC entry 363 (class 1255 OID 16442)
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- TOC entry 4553 (class 0 OID 0)
-- Dependencies: 363
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- TOC entry 544 (class 1255 OID 16443)
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
  BEGIN
    IF EXISTS (
      SELECT 1
      FROM pg_event_trigger_ddl_commands() AS ev
      JOIN pg_extension AS ext
      ON ev.objid = ext.oid
      WHERE ext.extname = 'pg_net'
    )
    THEN
      GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END;
  $$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO postgres;

--
-- TOC entry 4555 (class 0 OID 0)
-- Dependencies: 544
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- TOC entry 507 (class 1255 OID 16469)
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- TOC entry 367 (class 1255 OID 16470)
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- TOC entry 549 (class 1255 OID 16471)
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- TOC entry 4584 (class 0 OID 0)
-- Dependencies: 549
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- TOC entry 410 (class 1255 OID 16498)
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: postgres
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE WARNING 'PgBouncer auth request: %', p_usename;

    RETURN QUERY
    SELECT usename::TEXT, passwd::TEXT FROM pg_catalog.pg_shadow
    WHERE usename = p_usename;
END;
$$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO postgres;

--
-- TOC entry 563 (class 1255 OID 16645)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- TOC entry 508 (class 1255 OID 16647)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- TOC entry 564 (class 1255 OID 16648)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- TOC entry 582 (class 1255 OID 16649)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- TOC entry 583 (class 1255 OID 16650)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- TOC entry 589 (class 1255 OID 16651)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- TOC entry 588 (class 1255 OID 16652)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- TOC entry 590 (class 1255 OID 16653)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- TOC entry 510 (class 1255 OID 16654)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  partition_name text;
BEGIN
  partition_name := 'messages_' || to_char(NOW(), 'YYYY_MM_DD');

  IF NOT EXISTS (
    SELECT 1
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'realtime'
    AND c.relname = partition_name
  ) THEN
    EXECUTE format(
      'CREATE TABLE realtime.%I PARTITION OF realtime.messages FOR VALUES FROM (%L) TO (%L)',
      partition_name,
      NOW(),
      (NOW() + interval '1 day')::timestamp
    );
  END IF;

  INSERT INTO realtime.messages (payload, event, topic, private, extension)
  VALUES (payload, event, topic, private, 'broadcast');
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- TOC entry 591 (class 1255 OID 16655)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- TOC entry 515 (class 1255 OID 16656)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- TOC entry 516 (class 1255 OID 16657)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- TOC entry 517 (class 1255 OID 16658)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- TOC entry 518 (class 1255 OID 16659)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 511 (class 1255 OID 16660)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 512 (class 1255 OID 16661)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- TOC entry 513 (class 1255 OID 16662)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- TOC entry 514 (class 1255 OID 16663)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- TOC entry 592 (class 1255 OID 16664)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- TOC entry 520 (class 1255 OID 16665)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- TOC entry 519 (class 1255 OID 16666)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(objects.path_tokens, 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- TOC entry 524 (class 1255 OID 16667)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- TOC entry 594 (class 1255 OID 16668)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
    DECLARE
      request_id bigint;
      payload jsonb;
      url text := TG_ARGV[0]::text;
      method text := TG_ARGV[1]::text;
      headers jsonb DEFAULT '{}'::jsonb;
      params jsonb DEFAULT '{}'::jsonb;
      timeout_ms integer DEFAULT 1000;
    BEGIN
      IF url IS NULL OR url = 'null' THEN
        RAISE EXCEPTION 'url argument is missing';
      END IF;

      IF method IS NULL OR method = 'null' THEN
        RAISE EXCEPTION 'method argument is missing';
      END IF;

      IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
        headers = '{"Content-Type": "application/json"}'::jsonb;
      ELSE
        headers = TG_ARGV[2]::jsonb;
      END IF;

      IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
        params = '{}'::jsonb;
      ELSE
        params = TG_ARGV[3]::jsonb;
      END IF;

      IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
        timeout_ms = 1000;
      ELSE
        timeout_ms = TG_ARGV[4]::integer;
      END IF;

      CASE
        WHEN method = 'GET' THEN
          SELECT http_get INTO request_id FROM net.http_get(
            url,
            params,
            headers,
            timeout_ms
          );
        WHEN method = 'POST' THEN
          payload = jsonb_build_object(
            'old_record', OLD,
            'record', NEW,
            'type', TG_OP,
            'table', TG_TABLE_NAME,
            'schema', TG_TABLE_SCHEMA
          );

          SELECT http_post INTO request_id FROM net.http_post(
            url,
            payload,
            params,
            headers,
            timeout_ms
          );
        ELSE
          RAISE EXCEPTION 'method argument % is invalid', method;
      END CASE;

      INSERT INTO supabase_functions.hooks
        (hook_table_id, hook_name, request_id)
      VALUES
        (TG_RELID, TG_NAME, request_id);

      RETURN NEW;
    END
  $$;


ALTER FUNCTION supabase_functions.http_request() OWNER TO supabase_functions_admin;

--
-- TOC entry 522 (class 1255 OID 16670)
-- Name: secrets_encrypt_secret_secret(); Type: FUNCTION; Schema: vault; Owner: supabase_admin
--

CREATE FUNCTION vault.secrets_encrypt_secret_secret() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		BEGIN
		        new.secret = CASE WHEN new.secret IS NULL THEN NULL ELSE
			CASE WHEN new.key_id IS NULL THEN NULL ELSE pg_catalog.encode(
			  pgsodium.crypto_aead_det_encrypt(
				pg_catalog.convert_to(new.secret, 'utf8'),
				pg_catalog.convert_to((new.id::text || new.description::text || new.created_at::text || new.updated_at::text)::text, 'utf8'),
				new.key_id::uuid,
				new.nonce
			  ),
				'base64') END END;
		RETURN new;
		END;
		$$;


ALTER FUNCTION vault.secrets_encrypt_secret_secret() OWNER TO supabase_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 263 (class 1259 OID 29480)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- TOC entry 4630 (class 0 OID 0)
-- Dependencies: 263
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 264 (class 1259 OID 29486)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- TOC entry 4632 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 265 (class 1259 OID 29491)
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- TOC entry 4634 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4635 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 266 (class 1259 OID 29498)
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- TOC entry 4637 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 267 (class 1259 OID 29503)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- TOC entry 4639 (class 0 OID 0)
-- Dependencies: 267
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 268 (class 1259 OID 29508)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- TOC entry 4641 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 269 (class 1259 OID 29513)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- TOC entry 4643 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 270 (class 1259 OID 29518)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 271 (class 1259 OID 29526)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 4646 (class 0 OID 0)
-- Dependencies: 271
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 272 (class 1259 OID 29531)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- TOC entry 4648 (class 0 OID 0)
-- Dependencies: 272
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 273 (class 1259 OID 29532)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 4650 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 274 (class 1259 OID 29540)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- TOC entry 4652 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 275 (class 1259 OID 29546)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- TOC entry 4654 (class 0 OID 0)
-- Dependencies: 275
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 276 (class 1259 OID 29549)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- TOC entry 4656 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4657 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 277 (class 1259 OID 29554)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- TOC entry 4659 (class 0 OID 0)
-- Dependencies: 277
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 278 (class 1259 OID 29560)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 4661 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4662 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 279 (class 1259 OID 29566)
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- TOC entry 4664 (class 0 OID 0)
-- Dependencies: 279
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4665 (class 0 OID 0)
-- Dependencies: 279
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 328 (class 1259 OID 181333)
-- Name: ai_request_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_request_logs (
    id bigint NOT NULL,
    function_name text,
    prompt text,
    response text,
    model_used text,
    created_at timestamp with time zone,
    lead_id bigint,
    email_campaign_id bigint,
    updated_at timestamp without time zone,
    project_id bigint,
    tokens_used integer,
    campaign_id bigint,
    duration_ms integer,
    status text,
    error text
);


ALTER TABLE public.ai_request_logs OWNER TO postgres;

--
-- TOC entry 327 (class 1259 OID 181332)
-- Name: ai_request_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_request_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_request_logs_id_seq OWNER TO postgres;

--
-- TOC entry 4674 (class 0 OID 0)
-- Dependencies: 327
-- Name: ai_request_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_request_logs_id_seq OWNED BY public.ai_request_logs.id;


--
-- TOC entry 330 (class 1259 OID 181342)
-- Name: automation_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.automation_logs (
    id bigint NOT NULL,
    campaign_id bigint,
    search_term_id bigint,
    leads_gathered bigint,
    emails_sent bigint,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    status text,
    logs json,
    duration_seconds integer,
    updated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    error text
);


ALTER TABLE public.automation_logs OWNER TO postgres;

--
-- TOC entry 329 (class 1259 OID 181341)
-- Name: automation_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.automation_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.automation_logs_id_seq OWNER TO postgres;

--
-- TOC entry 4675 (class 0 OID 0)
-- Dependencies: 329
-- Name: automation_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.automation_logs_id_seq OWNED BY public.automation_logs.id;


--
-- TOC entry 334 (class 1259 OID 181360)
-- Name: background_process_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.background_process_state (
    id bigint NOT NULL,
    process_id text,
    status text,
    started_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    progress double precision,
    total_items integer,
    processed_items integer,
    process_type text,
    meta_data jsonb,
    project_id bigint,
    campaign_id bigint,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.background_process_state OWNER TO postgres;

--
-- TOC entry 333 (class 1259 OID 181359)
-- Name: background_process_state_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.background_process_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.background_process_state_id_seq OWNER TO postgres;

--
-- TOC entry 4676 (class 0 OID 0)
-- Dependencies: 333
-- Name: background_process_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.background_process_state_id_seq OWNED BY public.background_process_state.id;


--
-- TOC entry 314 (class 1259 OID 181213)
-- Name: campaign_leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaign_leads (
    id bigint NOT NULL,
    campaign_id bigint,
    lead_id bigint,
    status text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.campaign_leads OWNER TO postgres;

--
-- TOC entry 313 (class 1259 OID 181212)
-- Name: campaign_leads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaign_leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaign_leads_id_seq OWNER TO postgres;

--
-- TOC entry 4677 (class 0 OID 0)
-- Dependencies: 313
-- Name: campaign_leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaign_leads_id_seq OWNED BY public.campaign_leads.id;


--
-- TOC entry 343 (class 1259 OID 181407)
-- Name: campaign_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaign_metrics (
    id integer NOT NULL,
    campaign_id integer,
    event_type text,
    "timestamp" timestamp without time zone,
    value double precision,
    metric_metadata json
);


ALTER TABLE public.campaign_metrics OWNER TO postgres;

--
-- TOC entry 342 (class 1259 OID 181406)
-- Name: campaign_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaign_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaign_metrics_id_seq OWNER TO postgres;

--
-- TOC entry 4678 (class 0 OID 0)
-- Dependencies: 342
-- Name: campaign_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaign_metrics_id_seq OWNED BY public.campaign_metrics.id;


--
-- TOC entry 308 (class 1259 OID 181168)
-- Name: campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaigns (
    id bigint NOT NULL,
    campaign_name text,
    campaign_type text,
    project_id bigint,
    created_at timestamp with time zone DEFAULT now(),
    auto_send boolean,
    loop_automation boolean,
    ai_customization boolean,
    max_emails_per_group bigint,
    loop_interval bigint,
    metrics jsonb,
    updated_at timestamp without time zone,
    status text DEFAULT 'active'::text
);


ALTER TABLE public.campaigns OWNER TO postgres;

--
-- TOC entry 307 (class 1259 OID 181167)
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaigns_id_seq OWNER TO postgres;

--
-- TOC entry 4679 (class 0 OID 0)
-- Dependencies: 307
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaigns_id_seq OWNED BY public.campaigns.id;


--
-- TOC entry 318 (class 1259 OID 181248)
-- Name: email_campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_campaigns (
    id bigint NOT NULL,
    campaign_id bigint,
    lead_id bigint,
    template_id bigint,
    customized_subject text,
    customized_content text,
    original_subject text,
    original_content text,
    status text,
    engagement_data json,
    message_id text,
    tracking_id text,
    sent_at timestamp with time zone,
    ai_customized boolean,
    opened_at timestamp with time zone,
    clicked_at timestamp with time zone,
    open_count bigint,
    click_count bigint,
    updated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.email_campaigns OWNER TO postgres;

--
-- TOC entry 317 (class 1259 OID 181247)
-- Name: email_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_campaigns_id_seq OWNER TO postgres;

--
-- TOC entry 4680 (class 0 OID 0)
-- Dependencies: 317
-- Name: email_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_campaigns_id_seq OWNED BY public.email_campaigns.id;


--
-- TOC entry 332 (class 1259 OID 181351)
-- Name: email_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_settings (
    id bigint NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    provider text NOT NULL,
    smtp_server text,
    smtp_port bigint,
    smtp_username text,
    smtp_password text,
    aws_access_key_id text,
    aws_secret_access_key text,
    aws_region text,
    created_at timestamp with time zone,
    updated_at timestamp without time zone,
    project_id bigint,
    hourly_limit integer,
    is_active boolean DEFAULT true,
    daily_limit integer,
    settings jsonb
);


ALTER TABLE public.email_settings OWNER TO postgres;

--
-- TOC entry 331 (class 1259 OID 181350)
-- Name: email_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_settings_id_seq OWNER TO postgres;

--
-- TOC entry 4681 (class 0 OID 0)
-- Dependencies: 331
-- Name: email_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_settings_id_seq OWNED BY public.email_settings.id;


--
-- TOC entry 312 (class 1259 OID 181198)
-- Name: email_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_templates (
    id bigint NOT NULL,
    campaign_id bigint,
    template_name text,
    subject text,
    body_content text,
    created_at timestamp with time zone DEFAULT now(),
    is_ai_customizable boolean,
    language text,
    updated_at timestamp with time zone,
    template_type text,
    project_id bigint,
    variables jsonb
);


ALTER TABLE public.email_templates OWNER TO postgres;

--
-- TOC entry 311 (class 1259 OID 181197)
-- Name: email_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_templates_id_seq OWNER TO postgres;

--
-- TOC entry 4682 (class 0 OID 0)
-- Dependencies: 311
-- Name: email_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_templates_id_seq OWNED BY public.email_templates.id;


--
-- TOC entry 341 (class 1259 OID 181398)
-- Name: error_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.error_events (
    id integer NOT NULL,
    message text,
    "timestamp" timestamp without time zone,
    severity text,
    error_metadata json
);


ALTER TABLE public.error_events OWNER TO postgres;

--
-- TOC entry 340 (class 1259 OID 181397)
-- Name: error_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.error_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_events_id_seq OWNER TO postgres;

--
-- TOC entry 4683 (class 0 OID 0)
-- Dependencies: 340
-- Name: error_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.error_events_id_seq OWNED BY public.error_events.id;


--
-- TOC entry 310 (class 1259 OID 181183)
-- Name: knowledge_base; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_base (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    kb_name text,
    kb_bio text,
    kb_values text,
    contact_name text,
    contact_role text,
    contact_email text,
    company_description text,
    company_mission text,
    company_target_market text,
    company_other text,
    product_name text,
    product_description text,
    product_target_customer text,
    product_other text,
    other_context text,
    example_email text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    communication_style text,
    tone_of_voice text
);


ALTER TABLE public.knowledge_base OWNER TO postgres;

--
-- TOC entry 309 (class 1259 OID 181182)
-- Name: knowledge_base_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knowledge_base_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knowledge_base_id_seq OWNER TO postgres;

--
-- TOC entry 4684 (class 0 OID 0)
-- Dependencies: 309
-- Name: knowledge_base_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knowledge_base_id_seq OWNED BY public.knowledge_base.id;


--
-- TOC entry 320 (class 1259 OID 181274)
-- Name: lead_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_sources (
    id bigint NOT NULL,
    lead_id bigint,
    search_term_id bigint,
    url text,
    domain text,
    page_title text,
    meta_description text,
    scrape_duration text,
    meta_tags text,
    phone_numbers text,
    content text,
    tags text,
    http_status bigint,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.lead_sources OWNER TO postgres;

--
-- TOC entry 319 (class 1259 OID 181273)
-- Name: lead_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_sources_id_seq OWNER TO postgres;

--
-- TOC entry 4685 (class 0 OID 0)
-- Dependencies: 319
-- Name: lead_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_sources_id_seq OWNED BY public.lead_sources.id;


--
-- TOC entry 306 (class 1259 OID 181156)
-- Name: leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leads (
    id bigint NOT NULL,
    email text,
    phone text,
    first_name text,
    last_name text,
    company text,
    job_title text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.leads OWNER TO postgres;

--
-- TOC entry 305 (class 1259 OID 181155)
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leads_id_seq OWNER TO postgres;

--
-- TOC entry 4686 (class 0 OID 0)
-- Dependencies: 305
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- TOC entry 336 (class 1259 OID 181372)
-- Name: optimized_search_terms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.optimized_search_terms (
    id bigint NOT NULL,
    original_term_id bigint,
    term text,
    created_at timestamp with time zone,
    effectiveness_score double precision,
    updated_at timestamp without time zone,
    meta_data jsonb,
    project_id bigint,
    campaign_id bigint,
    is_active boolean DEFAULT true
);


ALTER TABLE public.optimized_search_terms OWNER TO postgres;

--
-- TOC entry 335 (class 1259 OID 181371)
-- Name: optimized_search_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.optimized_search_terms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.optimized_search_terms_id_seq OWNER TO postgres;

--
-- TOC entry 4687 (class 0 OID 0)
-- Dependencies: 335
-- Name: optimized_search_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.optimized_search_terms_id_seq OWNED BY public.optimized_search_terms.id;


--
-- TOC entry 304 (class 1259 OID 181146)
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    project_name text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- TOC entry 303 (class 1259 OID 181145)
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO postgres;

--
-- TOC entry 4688 (class 0 OID 0)
-- Dependencies: 303
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- TOC entry 337 (class 1259 OID 181380)
-- Name: search_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_groups (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description text,
    emails_sent integer,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_active boolean DEFAULT true,
    project_id bigint,
    campaign_id bigint,
    meta_data jsonb
);


ALTER TABLE public.search_groups OWNER TO postgres;

--
-- TOC entry 339 (class 1259 OID 181388)
-- Name: search_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_logs (
    id bigint NOT NULL,
    message text,
    level text,
    created_at timestamp with time zone DEFAULT now(),
    process_id text
);


ALTER TABLE public.search_logs OWNER TO postgres;

--
-- TOC entry 338 (class 1259 OID 181387)
-- Name: search_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_logs_id_seq OWNER TO postgres;

--
-- TOC entry 4689 (class 0 OID 0)
-- Dependencies: 338
-- Name: search_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_logs_id_seq OWNED BY public.search_logs.id;


--
-- TOC entry 324 (class 1259 OID 181306)
-- Name: search_term_effectiveness; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_term_effectiveness (
    id bigint NOT NULL,
    search_term_id bigint,
    effectiveness_score double precision,
    total_leads integer,
    valid_leads integer,
    created_at timestamp with time zone DEFAULT now(),
    irrelevant_leads integer,
    directories_found integer,
    updated_at timestamp without time zone,
    blogs_found integer
);


ALTER TABLE public.search_term_effectiveness OWNER TO postgres;

--
-- TOC entry 323 (class 1259 OID 181305)
-- Name: search_term_effectiveness_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_term_effectiveness_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_term_effectiveness_id_seq OWNER TO postgres;

--
-- TOC entry 4690 (class 0 OID 0)
-- Dependencies: 323
-- Name: search_term_effectiveness_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_term_effectiveness_id_seq OWNED BY public.search_term_effectiveness.id;


--
-- TOC entry 322 (class 1259 OID 181296)
-- Name: search_term_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_term_groups (
    id bigint NOT NULL,
    name text NOT NULL,
    email_template text,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    project_id bigint
);


ALTER TABLE public.search_term_groups OWNER TO postgres;

--
-- TOC entry 321 (class 1259 OID 181295)
-- Name: search_term_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_term_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_term_groups_id_seq OWNER TO postgres;

--
-- TOC entry 4691 (class 0 OID 0)
-- Dependencies: 321
-- Name: search_term_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_term_groups_id_seq OWNED BY public.search_term_groups.id;


--
-- TOC entry 316 (class 1259 OID 181233)
-- Name: search_terms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_terms (
    id bigint NOT NULL,
    campaign_id bigint,
    term text,
    category text,
    created_at timestamp with time zone DEFAULT now(),
    language text,
    project_id bigint,
    updated_at timestamp without time zone,
    group_id bigint
);


ALTER TABLE public.search_terms OWNER TO postgres;

--
-- TOC entry 315 (class 1259 OID 181232)
-- Name: search_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_terms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_terms_id_seq OWNER TO postgres;

--
-- TOC entry 4692 (class 0 OID 0)
-- Dependencies: 315
-- Name: search_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_terms_id_seq OWNED BY public.search_terms.id;


--
-- TOC entry 326 (class 1259 OID 181319)
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    name text NOT NULL,
    setting_type text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- TOC entry 325 (class 1259 OID 181318)
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO postgres;

--
-- TOC entry 4693 (class 0 OID 0)
-- Dependencies: 325
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- TOC entry 291 (class 1259 OID 104356)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- TOC entry 292 (class 1259 OID 165600)
-- Name: messages_2024_12_23; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2024_12_23 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2024_12_23 OWNER TO supabase_admin;

--
-- TOC entry 293 (class 1259 OID 170520)
-- Name: messages_2024_12_24; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2024_12_24 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2024_12_24 OWNER TO supabase_admin;

--
-- TOC entry 294 (class 1259 OID 170531)
-- Name: messages_2024_12_25; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2024_12_25 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2024_12_25 OWNER TO supabase_admin;

--
-- TOC entry 295 (class 1259 OID 170542)
-- Name: messages_2024_12_26; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2024_12_26 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2024_12_26 OWNER TO supabase_admin;

--
-- TOC entry 297 (class 1259 OID 170562)
-- Name: messages_2024_12_27; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.messages_2024_12_27 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE realtime.messages_2024_12_27 OWNER TO supabase_admin;

--
-- TOC entry 280 (class 1259 OID 29593)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- TOC entry 281 (class 1259 OID 29596)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- TOC entry 282 (class 1259 OID 29604)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 283 (class 1259 OID 29605)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- TOC entry 4703 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 284 (class 1259 OID 29614)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- TOC entry 285 (class 1259 OID 29618)
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- TOC entry 4706 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 286 (class 1259 OID 29628)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- TOC entry 287 (class 1259 OID 29635)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- TOC entry 288 (class 1259 OID 29643)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


ALTER TABLE supabase_functions.hooks OWNER TO supabase_functions_admin;

--
-- TOC entry 4710 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: supabase_functions_admin
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 289 (class 1259 OID 29649)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE supabase_functions.hooks_id_seq OWNER TO supabase_functions_admin;

--
-- TOC entry 4712 (class 0 OID 0)
-- Dependencies: 289
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 290 (class 1259 OID 29650)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE supabase_functions.migrations OWNER TO supabase_functions_admin;

--
-- TOC entry 296 (class 1259 OID 170554)
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- TOC entry 259 (class 1259 OID 29352)
-- Name: decrypted_secrets; Type: VIEW; Schema: vault; Owner: supabase_admin
--

CREATE VIEW vault.decrypted_secrets AS
 SELECT secrets.id,
    secrets.name,
    secrets.description,
    secrets.secret,
        CASE
            WHEN (secrets.secret IS NULL) THEN NULL::text
            ELSE
            CASE
                WHEN (secrets.key_id IS NULL) THEN NULL::text
                ELSE convert_from(pgsodium.crypto_aead_det_decrypt(decode(secrets.secret, 'base64'::text), convert_to(((((secrets.id)::text || secrets.description) || (secrets.created_at)::text) || (secrets.updated_at)::text), 'utf8'::name), secrets.key_id, secrets.nonce), 'utf8'::name)
            END
        END AS decrypted_secret,
    secrets.key_id,
    secrets.nonce,
    secrets.created_at,
    secrets.updated_at
   FROM vault.secrets;


ALTER TABLE vault.decrypted_secrets OWNER TO supabase_admin;

--
-- TOC entry 3889 (class 0 OID 0)
-- Name: messages_2024_12_23; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2024_12_23 FOR VALUES FROM ('2024-12-23 00:00:00') TO ('2024-12-24 00:00:00');


--
-- TOC entry 3890 (class 0 OID 0)
-- Name: messages_2024_12_24; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2024_12_24 FOR VALUES FROM ('2024-12-24 00:00:00') TO ('2024-12-25 00:00:00');


--
-- TOC entry 3891 (class 0 OID 0)
-- Name: messages_2024_12_25; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2024_12_25 FOR VALUES FROM ('2024-12-25 00:00:00') TO ('2024-12-26 00:00:00');


--
-- TOC entry 3892 (class 0 OID 0)
-- Name: messages_2024_12_26; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2024_12_26 FOR VALUES FROM ('2024-12-26 00:00:00') TO ('2024-12-27 00:00:00');


--
-- TOC entry 3893 (class 0 OID 0)
-- Name: messages_2024_12_27; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2024_12_27 FOR VALUES FROM ('2024-12-27 00:00:00') TO ('2024-12-28 00:00:00');


--
-- TOC entry 3911 (class 2604 OID 16808)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3998 (class 2604 OID 181336)
-- Name: ai_request_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_request_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_request_logs_id_seq'::regclass);


--
-- TOC entry 3999 (class 2604 OID 181345)
-- Name: automation_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.automation_logs ALTER COLUMN id SET DEFAULT nextval('public.automation_logs_id_seq'::regclass);


--
-- TOC entry 4003 (class 2604 OID 181363)
-- Name: background_process_state id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_process_state ALTER COLUMN id SET DEFAULT nextval('public.background_process_state_id_seq'::regclass);


--
-- TOC entry 3984 (class 2604 OID 181216)
-- Name: campaign_leads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_leads ALTER COLUMN id SET DEFAULT nextval('public.campaign_leads_id_seq'::regclass);


--
-- TOC entry 4012 (class 2604 OID 181410)
-- Name: campaign_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_metrics ALTER COLUMN id SET DEFAULT nextval('public.campaign_metrics_id_seq'::regclass);


--
-- TOC entry 3977 (class 2604 OID 181171)
-- Name: campaigns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns ALTER COLUMN id SET DEFAULT nextval('public.campaigns_id_seq'::regclass);


--
-- TOC entry 3988 (class 2604 OID 181251)
-- Name: email_campaigns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_campaigns ALTER COLUMN id SET DEFAULT nextval('public.email_campaigns_id_seq'::regclass);


--
-- TOC entry 4001 (class 2604 OID 181354)
-- Name: email_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_settings ALTER COLUMN id SET DEFAULT nextval('public.email_settings_id_seq'::regclass);


--
-- TOC entry 3982 (class 2604 OID 181201)
-- Name: email_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates ALTER COLUMN id SET DEFAULT nextval('public.email_templates_id_seq'::regclass);


--
-- TOC entry 4011 (class 2604 OID 181401)
-- Name: error_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.error_events ALTER COLUMN id SET DEFAULT nextval('public.error_events_id_seq'::regclass);


--
-- TOC entry 3980 (class 2604 OID 181186)
-- Name: knowledge_base id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base ALTER COLUMN id SET DEFAULT nextval('public.knowledge_base_id_seq'::regclass);


--
-- TOC entry 3990 (class 2604 OID 181277)
-- Name: lead_sources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources ALTER COLUMN id SET DEFAULT nextval('public.lead_sources_id_seq'::regclass);


--
-- TOC entry 3975 (class 2604 OID 181159)
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- TOC entry 4006 (class 2604 OID 181375)
-- Name: optimized_search_terms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimized_search_terms ALTER COLUMN id SET DEFAULT nextval('public.optimized_search_terms_id_seq'::regclass);


--
-- TOC entry 3973 (class 2604 OID 181149)
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- TOC entry 4009 (class 2604 OID 181391)
-- Name: search_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_logs ALTER COLUMN id SET DEFAULT nextval('public.search_logs_id_seq'::regclass);


--
-- TOC entry 3994 (class 2604 OID 181309)
-- Name: search_term_effectiveness id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_term_effectiveness ALTER COLUMN id SET DEFAULT nextval('public.search_term_effectiveness_id_seq'::regclass);


--
-- TOC entry 3992 (class 2604 OID 181299)
-- Name: search_term_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_term_groups ALTER COLUMN id SET DEFAULT nextval('public.search_term_groups_id_seq'::regclass);


--
-- TOC entry 3986 (class 2604 OID 181236)
-- Name: search_terms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_terms ALTER COLUMN id SET DEFAULT nextval('public.search_terms_id_seq'::regclass);


--
-- TOC entry 3996 (class 2604 OID 181322)
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- TOC entry 3939 (class 2604 OID 16841)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4423 (class 0 OID 29480)
-- Dependencies: 263
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- TOC entry 4424 (class 0 OID 29486)
-- Dependencies: 264
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4425 (class 0 OID 29491)
-- Dependencies: 265
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- TOC entry 4426 (class 0 OID 29498)
-- Dependencies: 266
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4427 (class 0 OID 29503)
-- Dependencies: 267
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- TOC entry 4428 (class 0 OID 29508)
-- Dependencies: 268
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4429 (class 0 OID 29513)
-- Dependencies: 269
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4430 (class 0 OID 29518)
-- Dependencies: 270
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4431 (class 0 OID 29526)
-- Dependencies: 271
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- TOC entry 4433 (class 0 OID 29532)
-- Dependencies: 273
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4434 (class 0 OID 29540)
-- Dependencies: 274
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4435 (class 0 OID 29546)
-- Dependencies: 275
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
\.


--
-- TOC entry 4436 (class 0 OID 29549)
-- Dependencies: 276
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
\.


--
-- TOC entry 4437 (class 0 OID 29554)
-- Dependencies: 277
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4438 (class 0 OID 29560)
-- Dependencies: 278
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4439 (class 0 OID 29566)
-- Dependencies: 279
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- TOC entry 3885 (class 0 OID 176271)
-- Dependencies: 300
-- Data for Name: job; Type: TABLE DATA; Schema: cron; Owner: supabase_admin
--

COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active, jobname) FROM stdin;
\.


--
-- TOC entry 3887 (class 0 OID 176290)
-- Dependencies: 302
-- Data for Name: job_run_details; Type: TABLE DATA; Schema: cron; Owner: supabase_admin
--

COPY cron.job_run_details (jobid, runid, job_pid, database, username, command, status, return_message, start_time, end_time) FROM stdin;
\.


--
-- TOC entry 3882 (class 0 OID 29084)
-- Dependencies: 250
-- Data for Name: key; Type: TABLE DATA; Schema: pgsodium; Owner: supabase_admin
--

COPY pgsodium.key (id, status, created, expires, key_type, key_id, key_context, name, associated_data, raw_key, raw_key_nonce, parent_key, comment, user_data) FROM stdin;
26dd0c40-de79-4658-93cc-7fc109b3e7a0	valid	2024-09-20 05:15:26.716981+00	\N	aead-det	1	\\x7067736f6469756d	OpenAI		\N	\N	\N	\N	\N
\.


--
-- TOC entry 4482 (class 0 OID 181333)
-- Dependencies: 328
-- Data for Name: ai_request_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_request_logs (id, function_name, prompt, response, model_used, created_at, lead_id, email_campaign_id, updated_at, project_id, tokens_used, campaign_id, duration_ms, status, error) FROM stdin;
\.


--
-- TOC entry 4484 (class 0 OID 181342)
-- Dependencies: 330
-- Data for Name: automation_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.automation_logs (id, campaign_id, search_term_id, leads_gathered, emails_sent, start_time, end_time, status, logs, duration_seconds, updated_at, created_at, error) FROM stdin;
\.


--
-- TOC entry 4488 (class 0 OID 181360)
-- Dependencies: 334
-- Data for Name: background_process_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.background_process_state (id, process_id, status, started_at, updated_at, completed_at, error_message, progress, total_items, processed_items, process_type, meta_data, project_id, campaign_id, created_at) FROM stdin;
1	8473b8d6-aaf6-4e1a-bebe-914611601052	running	2025-01-03 00:55:17.964465+00	2025-01-03 00:55:18.220307+00	\N	{"timestamp": "2025-01-03T00:55:18.252662", "message": "Starting search for term: software development company", "level": "search"}	0	1	0	\N	\N	\N	\N	2025-01-05 17:48:50.530196
2	6a651b85-37b5-4fa2-8dee-3c6859ad5142	failed	2025-01-03 00:56:33.195261+00	2025-01-03 00:56:56.292861+00	2025-01-03 00:56:56.32955+00	'Email'	0	1	0	\N	\N	\N	\N	2025-01-05 17:48:50.530196
3	76167e47-49b4-4ccf-8fbd-21bd92d3bf8e	completed	2025-01-03 03:15:34.290307+00	2025-01-03 03:15:39.194849+00	2025-01-03 03:15:39.223855+00	{"timestamp": "2025-01-03T03:15:38.938141", "message": "No results found for term: software development company", "level": "warning"}	100	1	1	\N	\N	\N	\N	2025-01-05 17:48:50.530196
4	e1c7256c-2937-40ba-9a7c-9f9eff08cb6b	completed	2025-01-06 03:24:06.181074+00	\N	2025-01-06 04:24:14.706294+00	\N	100	1	1	\N	\N	\N	\N	2025-01-06 03:24:06.181074
5	1cfd239f-fd37-4c1a-a2b1-e11002a323c9	completed	2025-01-06 03:24:51.78876+00	\N	2025-01-06 04:24:59.59306+00	\N	100	1	1	\N	\N	\N	\N	2025-01-06 03:24:51.78876
\.


--
-- TOC entry 4468 (class 0 OID 181213)
-- Dependencies: 314
-- Data for Name: campaign_leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campaign_leads (id, campaign_id, lead_id, status, created_at, updated_at) FROM stdin;
1	1	1	Not Contacted	2025-01-03 00:55:23.394684+00	\N
2	1	2	Not Contacted	2025-01-03 00:55:23.982232+00	\N
3	1	2	Not Contacted	2025-01-03 00:55:24.461152+00	\N
4	1	2	Not Contacted	2025-01-03 00:55:24.907637+00	\N
5	1	2	Not Contacted	2025-01-03 00:55:25.369283+00	\N
6	1	2	Not Contacted	2025-01-03 00:55:27.256395+00	\N
7	1	2	Not Contacted	2025-01-03 00:55:27.721829+00	\N
8	1	2	Not Contacted	2025-01-03 00:55:28.124952+00	\N
9	1	3	Not Contacted	2025-01-03 00:55:28.64112+00	\N
10	1	4	Not Contacted	2025-01-03 00:55:29.155621+00	\N
11	1	3	Not Contacted	2025-01-03 00:55:29.599334+00	\N
12	1	5	Not Contacted	2025-01-03 00:55:30.026879+00	\N
13	1	6	Not Contacted	2025-01-03 00:55:30.506313+00	\N
14	1	2	Not Contacted	2025-01-03 00:55:30.941568+00	\N
15	1	2	Not Contacted	2025-01-03 00:55:31.331949+00	\N
16	1	7	Not Contacted	2025-01-03 00:55:32.536051+00	\N
17	1	7	Not Contacted	2025-01-03 00:55:33.020749+00	\N
18	1	7	Not Contacted	2025-01-03 00:55:33.497489+00	\N
19	1	7	Not Contacted	2025-01-03 00:55:33.981963+00	\N
20	1	7	Not Contacted	2025-01-03 00:55:34.535073+00	\N
21	1	7	Not Contacted	2025-01-03 00:55:34.97568+00	\N
22	1	8	Not Contacted	2025-01-03 00:55:35.584466+00	\N
23	1	8	Not Contacted	2025-01-03 00:55:36.052707+00	\N
24	1	9	Not Contacted	2025-01-03 00:55:36.553683+00	\N
25	1	9	Not Contacted	2025-01-03 00:55:37.079099+00	\N
26	1	7	Not Contacted	2025-01-03 00:55:37.516855+00	\N
27	1	7	Not Contacted	2025-01-03 00:55:37.937812+00	\N
28	1	7	Not Contacted	2025-01-03 00:55:38.448217+00	\N
29	1	7	Not Contacted	2025-01-03 00:55:38.927171+00	\N
30	1	7	Not Contacted	2025-01-03 00:55:39.377723+00	\N
31	1	1	Not Contacted	2025-01-03 00:56:37.671416+00	\N
32	1	2	Not Contacted	2025-01-03 00:56:38.045477+00	\N
33	1	2	Not Contacted	2025-01-03 00:56:38.447364+00	\N
34	1	2	Not Contacted	2025-01-03 00:56:38.911242+00	\N
35	1	2	Not Contacted	2025-01-03 00:56:39.280932+00	\N
36	1	2	Not Contacted	2025-01-03 00:56:39.759132+00	\N
37	1	2	Not Contacted	2025-01-03 00:56:40.106942+00	\N
38	1	2	Not Contacted	2025-01-03 00:56:40.466439+00	\N
39	1	1	Not Contacted	2025-01-03 00:56:41.432605+00	\N
40	1	2	Not Contacted	2025-01-03 00:56:41.81646+00	\N
41	1	2	Not Contacted	2025-01-03 00:56:42.174913+00	\N
42	1	2	Not Contacted	2025-01-03 00:56:42.590199+00	\N
43	1	2	Not Contacted	2025-01-03 00:56:42.942249+00	\N
44	1	2	Not Contacted	2025-01-03 00:56:43.522472+00	\N
45	1	2	Not Contacted	2025-01-03 00:56:43.924643+00	\N
46	1	2	Not Contacted	2025-01-03 00:56:44.302231+00	\N
47	1	1	Not Contacted	2025-01-03 00:56:45.371993+00	\N
48	1	2	Not Contacted	2025-01-03 00:56:45.81243+00	\N
49	1	2	Not Contacted	2025-01-03 00:56:46.172435+00	\N
50	1	2	Not Contacted	2025-01-03 00:56:46.58962+00	\N
51	1	2	Not Contacted	2025-01-03 00:56:46.978064+00	\N
52	1	2	Not Contacted	2025-01-03 00:56:47.431744+00	\N
53	1	2	Not Contacted	2025-01-03 00:56:47.807151+00	\N
54	1	2	Not Contacted	2025-01-03 00:56:48.187152+00	\N
55	1	2	Not Contacted	2025-01-03 00:56:48.578949+00	\N
56	1	2	Not Contacted	2025-01-03 00:56:48.954076+00	\N
57	1	2	Not Contacted	2025-01-03 00:56:49.489792+00	\N
58	1	4	Not Contacted	2025-01-03 00:56:49.862867+00	\N
59	1	4	Not Contacted	2025-01-03 00:56:50.206371+00	\N
60	1	3	Not Contacted	2025-01-03 00:56:50.570255+00	\N
61	1	3	Not Contacted	2025-01-03 00:56:50.91607+00	\N
62	1	3	Not Contacted	2025-01-03 00:56:51.337395+00	\N
63	1	3	Not Contacted	2025-01-03 00:56:51.710605+00	\N
64	1	3	Not Contacted	2025-01-03 00:56:52.118353+00	\N
65	1	3	Not Contacted	2025-01-03 00:56:52.624168+00	\N
66	1	5	Not Contacted	2025-01-03 00:56:53.054696+00	\N
67	1	5	Not Contacted	2025-01-03 00:56:53.440381+00	\N
68	1	6	Not Contacted	2025-01-03 00:56:53.825655+00	\N
69	1	6	Not Contacted	2025-01-03 00:56:54.219491+00	\N
70	1	2	Not Contacted	2025-01-03 00:56:54.588337+00	\N
71	1	2	Not Contacted	2025-01-03 00:56:54.934613+00	\N
72	1	2	Not Contacted	2025-01-03 00:56:55.302064+00	\N
73	1	10	Not Contacted	2025-01-06 03:24:13.849591+00	\N
\.


--
-- TOC entry 4497 (class 0 OID 181407)
-- Dependencies: 343
-- Data for Name: campaign_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campaign_metrics (id, campaign_id, event_type, "timestamp", value, metric_metadata) FROM stdin;
\.


--
-- TOC entry 4462 (class 0 OID 181168)
-- Dependencies: 308
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campaigns (id, campaign_name, campaign_type, project_id, created_at, auto_send, loop_automation, ai_customization, max_emails_per_group, loop_interval, metrics, updated_at, status) FROM stdin;
1	Test Campaign	Email	1	2025-01-02 16:47:22.130602+00	f	f	f	40	60	\N	\N	active
\.


--
-- TOC entry 4472 (class 0 OID 181248)
-- Dependencies: 318
-- Data for Name: email_campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_campaigns (id, campaign_id, lead_id, template_id, customized_subject, customized_content, original_subject, original_content, status, engagement_data, message_id, tracking_id, sent_at, ai_customized, opened_at, clicked_at, open_count, click_count, updated_at, created_at) FROM stdin;
\.


--
-- TOC entry 4486 (class 0 OID 181351)
-- Dependencies: 332
-- Data for Name: email_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_settings (id, name, email, provider, smtp_server, smtp_port, smtp_username, smtp_password, aws_access_key_id, aws_secret_access_key, aws_region, created_at, updated_at, project_id, hourly_limit, is_active, daily_limit, settings) FROM stdin;
1	Default SES	hello@indosy.com	ses	\N	\N	\N	\N	YOUR_AWS_ACCESS_KEY	YOUR_AWS_SECRET_KEY	eu-central-1	2025-01-03 00:52:10.127676+00	\N	\N	\N	t	\N	\N
2	Default SMTP	eugproductions@gmail.com	smtp	smtp.gmail.com	587	your_email@gmail.com	your_app_password	\N	\N	\N	2025-01-03 00:52:10.127832+00	\N	\N	\N	t	\N	\N
\.


--
-- TOC entry 4466 (class 0 OID 181198)
-- Dependencies: 312
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_templates (id, campaign_id, template_name, subject, body_content, created_at, is_ai_customizable, language, updated_at, template_type, project_id, variables) FROM stdin;
1	1	Test Template	Test Subject	Hello, this is a test email.	2025-01-02 16:47:30.635979+00	t	ES	\N	\N	\N	\N
\.


--
-- TOC entry 4495 (class 0 OID 181398)
-- Dependencies: 341
-- Data for Name: error_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.error_events (id, message, "timestamp", severity, error_metadata) FROM stdin;
1	'Notification' object has no attribute 'send'	2025-01-03 04:18:13.042819	ERROR	{"error_type": "General"}
2	'Notification' object has no attribute 'send'	2025-01-03 04:18:13.178881	ERROR	{"error_type": "General"}
3	'Notification' object has no attribute 'send'	2025-01-03 04:18:15.775117	ERROR	{"error_type": "General"}
4	'Notification' object has no attribute 'send'	2025-01-03 04:18:15.921225	ERROR	{"error_type": "General"}
5	'Notification' object has no attribute 'send'	2025-01-03 04:18:55.959783	ERROR	{"error_type": "General"}
6	'Notification' object has no attribute 'send'	2025-01-03 04:18:56.084318	ERROR	{"error_type": "General"}
7	'Notification' object has no attribute 'send'	2025-01-03 04:18:59.016867	ERROR	{"error_type": "General"}
8	'Notification' object has no attribute 'send'	2025-01-03 04:18:59.138797	ERROR	{"error_type": "General"}
9	'Button' object has no attribute 'on_click'	2025-01-03 04:28:31.536994	ERROR	{"error_type": "General"}
10	'Button' object has no attribute 'on_click'	2025-01-03 04:28:31.675782	ERROR	{"error_type": "General"}
11	'Button' object has no attribute 'on_click'	2025-01-03 04:28:33.313659	ERROR	{"error_type": "General"}
12	'Button' object has no attribute 'on_click'	2025-01-03 04:28:33.428675	ERROR	{"error_type": "General"}
13	'Button' object has no attribute 'on_click'	2025-01-03 04:29:32.783171	ERROR	{"error_type": "General"}
14	'Button' object has no attribute 'on_click'	2025-01-03 04:29:33.012721	ERROR	{"error_type": "General"}
15	'Button' object has no attribute 'on_click'	2025-01-03 04:29:33.14999	ERROR	{"error_type": "General"}
16	'Button' object has no attribute 'on_click'	2025-01-03 04:29:33.264361	ERROR	{"error_type": "General"}
17	'Button' object has no attribute 'on_click'	2025-01-03 04:29:34.959312	ERROR	{"error_type": "General"}
18	'Button' object has no attribute 'on_click'	2025-01-03 04:29:35.061427	ERROR	{"error_type": "General"}
19	'Button' object has no attribute 'on_click'	2025-01-03 04:30:11.700256	ERROR	{"error_type": "General"}
20	'Button' object has no attribute 'on_click'	2025-01-03 04:30:11.808012	ERROR	{"error_type": "General"}
21	'Button' object has no attribute 'on_click'	2025-01-03 04:30:13.178084	ERROR	{"error_type": "General"}
22	'Button' object has no attribute 'on_click'	2025-01-03 04:30:13.305245	ERROR	{"error_type": "General"}
\.


--
-- TOC entry 4464 (class 0 OID 181183)
-- Dependencies: 310
-- Data for Name: knowledge_base; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knowledge_base (id, project_id, kb_name, kb_bio, kb_values, contact_name, contact_role, contact_email, company_description, company_mission, company_target_market, company_other, product_name, product_description, product_target_customer, product_other, other_context, example_email, created_at, updated_at, communication_style, tone_of_voice) FROM stdin;
\.


--
-- TOC entry 4474 (class 0 OID 181274)
-- Dependencies: 320
-- Data for Name: lead_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_sources (id, lead_id, search_term_id, url, domain, page_title, meta_description, scrape_duration, meta_tags, phone_numbers, content, tags, http_status, created_at, updated_at) FROM stdin;
1	1	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:21.66052+00	\N
2	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:23.700951+00	\N
3	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:24.241481+00	\N
4	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:24.72398+00	\N
5	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:25.174877+00	\N
6	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:27.039294+00	\N
7	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:27.518186+00	\N
8	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:27.915792+00	\N
9	3	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:28.414431+00	\N
10	4	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:28.865713+00	\N
11	3	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:29.385076+00	\N
12	5	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:29.793505+00	\N
13	6	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:30.284887+00	\N
14	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:30.756797+00	\N
15	2	\N	https://www.scnsoft.com/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:31.141552+00	\N
16	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:31.542552+00	\N
17	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:32.795591+00	\N
18	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:33.281687+00	\N
19	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:33.764226+00	\N
20	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:34.321749+00	\N
21	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:34.790408+00	\N
22	8	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:35.357572+00	\N
23	8	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:35.864545+00	\N
24	9	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:36.328099+00	\N
25	9	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:36.858802+00	\N
26	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:37.299642+00	\N
27	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:37.726258+00	\N
28	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:38.195475+00	\N
29	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:38.678614+00	\N
30	7	\N	https://www.intellectsoft.net/	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:55:39.196215+00	\N
31	1	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:36.746538+00	\N
32	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:37.870541+00	\N
33	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:38.254915+00	\N
34	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:38.721901+00	\N
35	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:39.098979+00	\N
36	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:39.583235+00	\N
37	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:39.939792+00	\N
38	2	\N	https://www.scnsoft.com/software-development/services	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:40.295709+00	\N
39	1	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:40.643125+00	\N
40	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:41.620758+00	\N
41	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:42.003809+00	\N
42	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:42.378925+00	\N
43	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:42.776864+00	\N
44	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:43.305678+00	\N
45	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:43.728713+00	\N
46	2	\N	https://www.scnsoft.com/software-development/custom	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:44.120156+00	\N
47	1	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:44.476744+00	\N
48	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:45.571765+00	\N
49	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:46.009013+00	\N
50	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:46.360399+00	\N
51	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:46.805988+00	\N
52	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:47.222406+00	\N
53	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:47.639924+00	\N
54	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:47.99555+00	\N
55	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:48.403724+00	\N
56	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:48.77648+00	\N
57	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:49.322912+00	\N
58	4	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:49.690297+00	\N
59	4	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:50.043013+00	\N
60	3	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:50.396966+00	\N
61	3	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:50.7494+00	\N
62	3	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:51.123841+00	\N
63	3	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:51.519002+00	\N
64	3	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:51.938988+00	\N
65	3	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:52.320872+00	\N
66	5	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:52.858357+00	\N
67	5	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:53.246124+00	\N
68	6	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:53.640614+00	\N
69	6	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:54.043883+00	\N
70	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:54.415812+00	\N
71	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:54.770043+00	\N
72	2	\N	https://www.scnsoft.com/about/company	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-03 00:56:55.123421+00	\N
73	10	\N	https://www.imaginarycloud.com/blog/top-software-development-companies	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-01-06 03:24:09.745631+00	\N
\.


--
-- TOC entry 4460 (class 0 OID 181156)
-- Dependencies: 306
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leads (id, email, phone, first_name, last_name, company, job_title, created_at, updated_at) FROM stdin;
1	website-mon@scnsoft.com	\N		\N			2025-01-03 00:55:22.973867+00	\N
2	contact@scnsoft.com	\N		\N			2025-01-03 00:55:23.758065+00	\N
3	eu@scnsoft.com	\N		\N			2025-01-03 00:55:28.446559+00	\N
4	nordics@scnsoft.com	\N		\N			2025-01-03 00:55:28.92756+00	\N
5	ksa@scnsoft.com	\N		\N			2025-01-03 00:55:29.831144+00	\N
6	gulf@scnsoft.com	\N		\N			2025-01-03 00:55:30.31756+00	\N
7	info@intellectsoft.net	\N		\N	Intellectsoft		2025-01-03 00:55:32.322374+00	\N
8	info@intellectsoft.co.uk	\N		\N	Intellectsoft		2025-01-03 00:55:35.395055+00	\N
9	info@intellectsoft.no	\N		\N	Intellectsoft		2025-01-03 00:55:36.365543+00	\N
10	info@imaginarycloud.com	\N		\N			2025-01-06 03:24:13.658264+00	\N
\.


--
-- TOC entry 4490 (class 0 OID 181372)
-- Dependencies: 336
-- Data for Name: optimized_search_terms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.optimized_search_terms (id, original_term_id, term, created_at, effectiveness_score, updated_at, meta_data, project_id, campaign_id, is_active) FROM stdin;
\.


--
-- TOC entry 4458 (class 0 OID 181146)
-- Dependencies: 304
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, project_name, created_at, updated_at) FROM stdin;
1	Test Project	2025-01-02 16:47:22.130602+00	\N
\.


--
-- TOC entry 4491 (class 0 OID 181380)
-- Dependencies: 337
-- Data for Name: search_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_groups (id, name, description, emails_sent, created_at, updated_at, is_active, project_id, campaign_id, meta_data) FROM stdin;
\.


--
-- TOC entry 4493 (class 0 OID 181388)
-- Dependencies: 339
-- Data for Name: search_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_logs (id, message, level, created_at, process_id) FROM stdin;
\.


--
-- TOC entry 4478 (class 0 OID 181306)
-- Dependencies: 324
-- Data for Name: search_term_effectiveness; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_term_effectiveness (id, search_term_id, effectiveness_score, total_leads, valid_leads, created_at, irrelevant_leads, directories_found, updated_at, blogs_found) FROM stdin;
\.


--
-- TOC entry 4476 (class 0 OID 181296)
-- Dependencies: 322
-- Data for Name: search_term_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_term_groups (id, name, email_template, description, created_at, updated_at, project_id) FROM stdin;
\.


--
-- TOC entry 4470 (class 0 OID 181233)
-- Dependencies: 316
-- Data for Name: search_terms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.search_terms (id, campaign_id, term, category, created_at, language, project_id, updated_at, group_id) FROM stdin;
1	1	software development company	Technology	2025-01-02 16:47:36.658842+00	EN	\N	\N	\N
\.


--
-- TOC entry 4480 (class 0 OID 181319)
-- Dependencies: 326
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, name, setting_type, value, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4451 (class 0 OID 165600)
-- Dependencies: 292
-- Data for Name: messages_2024_12_23; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2024_12_23 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4452 (class 0 OID 170520)
-- Dependencies: 293
-- Data for Name: messages_2024_12_24; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2024_12_24 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4453 (class 0 OID 170531)
-- Dependencies: 294
-- Data for Name: messages_2024_12_25; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2024_12_25 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4454 (class 0 OID 170542)
-- Dependencies: 295
-- Data for Name: messages_2024_12_26; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2024_12_26 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4456 (class 0 OID 170562)
-- Dependencies: 297
-- Data for Name: messages_2024_12_27; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.messages_2024_12_27 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4440 (class 0 OID 29593)
-- Dependencies: 280
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2024-05-30 15:36:41
20211116045059	2024-05-30 15:36:41
20211116050929	2024-05-30 15:36:41
20211116051442	2024-05-30 15:36:41
20211116212300	2024-05-30 15:36:41
20211116213355	2024-05-30 15:36:42
20211116213934	2024-05-30 15:36:42
20211116214523	2024-05-30 15:36:42
20211122062447	2024-05-30 15:36:42
20211124070109	2024-05-30 15:36:42
20211202204204	2024-05-30 15:36:42
20211202204605	2024-05-30 15:36:43
20211210212804	2024-05-30 15:36:43
20211228014915	2024-05-30 15:36:43
20220107221237	2024-05-30 15:36:43
20220228202821	2024-05-30 15:36:44
20220312004840	2024-05-30 15:36:44
20220603231003	2024-05-30 15:36:44
20220603232444	2024-05-30 15:36:44
20220615214548	2024-05-30 15:36:44
20220712093339	2024-05-30 15:36:45
20220908172859	2024-05-30 15:36:45
20220916233421	2024-05-30 15:36:45
20230119133233	2024-05-30 15:36:45
20230128025114	2024-05-30 15:36:45
20230128025212	2024-05-30 15:36:45
20230227211149	2024-05-30 15:36:46
20230228184745	2024-05-30 15:36:46
20230308225145	2024-05-30 15:36:46
20230328144023	2024-05-30 15:36:46
20231018144023	2024-05-30 15:36:46
20231204144023	2024-05-30 15:36:47
20231204144024	2024-05-30 15:36:47
20231204144025	2024-05-30 15:36:47
20240108234812	2024-05-30 15:36:47
20240109165339	2024-05-30 15:36:47
20240227174441	2024-05-30 15:36:47
20240311171622	2024-05-30 15:36:48
20240321100241	2024-05-30 15:36:48
20240401105812	2024-05-30 15:36:48
20240418121054	2024-05-30 15:36:49
20240523004032	2024-08-25 17:56:42
20240618124746	2024-08-25 17:56:42
20240801235015	2024-08-25 17:56:42
20240805133720	2024-08-25 17:56:42
20240827160934	2024-09-06 14:56:18
20240919163303	2024-11-12 19:22:01
20240919163305	2024-11-12 19:22:01
20241019105805	2024-11-12 19:22:02
20241030150047	2024-11-12 19:22:02
20241108114728	2024-11-12 19:22:03
20241121104152	2024-11-28 02:10:45
20241130184212	2024-12-11 12:17:56
\.


--
-- TOC entry 4441 (class 0 OID 29596)
-- Dependencies: 281
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4443 (class 0 OID 29605)
-- Dependencies: 283
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id) FROM stdin;
\.


--
-- TOC entry 4444 (class 0 OID 29614)
-- Dependencies: 284
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2024-05-29 21:24:55.899921
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2024-05-29 21:24:55.95453
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2024-05-29 21:24:55.964992
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2024-05-29 21:24:55.991628
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2024-05-29 21:24:56.063756
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2024-05-29 21:24:56.11511
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2024-05-29 21:24:56.166309
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2024-05-29 21:24:56.218784
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2024-05-29 21:24:56.270514
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2024-05-29 21:24:56.322387
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2024-05-29 21:24:56.374697
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2024-05-29 21:24:56.459205
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2024-05-29 21:24:56.510718
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2024-05-29 21:24:56.562393
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2024-05-29 21:24:56.614185
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2024-05-29 21:24:56.687592
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2024-05-29 21:24:56.739164
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2024-05-29 21:24:56.792671
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2024-05-29 21:24:56.846646
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2024-05-29 21:24:56.902431
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2024-05-29 21:24:56.954963
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2024-05-29 21:24:57.014926
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2024-05-29 21:24:57.091753
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2024-05-29 21:24:57.164064
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2024-08-25 17:56:20.403716
25	custom-metadata	67eb93b7e8d401cafcdc97f9ac779e71a79bfe03	2024-08-25 17:56:20.461315
\.


--
-- TOC entry 4445 (class 0 OID 29618)
-- Dependencies: 285
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- TOC entry 4446 (class 0 OID 29628)
-- Dependencies: 286
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4447 (class 0 OID 29635)
-- Dependencies: 287
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4448 (class 0 OID 29643)
-- Dependencies: 288
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4450 (class 0 OID 29650)
-- Dependencies: 290
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: supabase_functions_admin
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2024-05-29 21:28:59.582094+00
20210809183423_update_grants	2024-05-29 21:28:59.582094+00
\.


--
-- TOC entry 4455 (class 0 OID 170554)
-- Dependencies: 296
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20241225233040	{"SET statement_timeout = 0","SET lock_timeout = 0","SET idle_in_transaction_session_timeout = 0","SET client_encoding = 'UTF8'","SET standard_conforming_strings = on","SELECT pg_catalog.set_config('search_path', '', false)","SET check_function_bodies = false","SET xmloption = content","SET client_min_messages = warning","SET row_security = off","CREATE EXTENSION IF NOT EXISTS \\"pg_net\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"pgsodium\\" WITH SCHEMA \\"pgsodium\\"","ALTER SCHEMA \\"public\\" OWNER TO \\"postgres\\"","CREATE SCHEMA IF NOT EXISTS \\"schemauser\\"","ALTER SCHEMA \\"schemauser\\" OWNER TO \\"postgres\\"","CREATE EXTENSION IF NOT EXISTS \\"pg_graphql\\" WITH SCHEMA \\"graphql\\"","CREATE EXTENSION IF NOT EXISTS \\"pg_stat_statements\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"pgcrypto\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"pgjwt\\" WITH SCHEMA \\"extensions\\"","CREATE EXTENSION IF NOT EXISTS \\"supabase_vault\\" WITH SCHEMA \\"vault\\"","CREATE EXTENSION IF NOT EXISTS \\"uuid-ossp\\" WITH SCHEMA \\"extensions\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"get_tables_info\\"() RETURNS TABLE(\\"table_name\\" \\"text\\", \\"columns\\" \\"jsonb\\")\n    LANGUAGE \\"plpgsql\\" SECURITY DEFINER\n    AS $$\nBEGIN\n  RETURN QUERY\n  SELECT\n    t.table_name::text,\n    jsonb_agg(\n      jsonb_build_object(\n        'column_name', c.column_name,\n        'data_type', c.data_type,\n        'is_nullable', c.is_nullable,\n        'column_default', c.column_default,\n        'udt_name', c.udt_name,\n        'character_maximum_length', c.character_maximum_length\n      ) \n      ORDER BY c.ordinal_position\n    ) AS columns\n  FROM\n    information_schema.tables t\n  JOIN\n    information_schema.columns c \n  ON\n    c.table_name = t.table_name \n    AND c.table_schema = t.table_schema\n  WHERE\n    t.table_schema = 'public'\n    AND t.table_type = 'BASE TABLE'\n    AND t.table_name NOT IN ('schema_migrations', '_prisma_migrations')\n  GROUP BY\n    t.table_name\n  ORDER BY\n    t.table_name;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"get_tables_info\\"() OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"log_email_fetch\\"(\\"term_id\\" bigint, \\"email\\" \\"text\\", \\"page_title\\" \\"text\\", \\"url\\" \\"text\\", \\"meta_description\\" \\"text\\", \\"http_status\\" integer, \\"scrape_duration\\" \\"text\\") RETURNS \\"void\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    INSERT INTO emails (search_term_id, email, page_title, url, meta_description, http_status, scrape_duration)\n    VALUES (term_id, email, page_title, url, meta_description, http_status, scrape_duration)\n    ON CONFLICT (email, search_term_id) DO NOTHING;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"log_email_fetch\\"(\\"term_id\\" bigint, \\"email\\" \\"text\\", \\"page_title\\" \\"text\\", \\"url\\" \\"text\\", \\"meta_description\\" \\"text\\", \\"http_status\\" integer, \\"scrape_duration\\" \\"text\\") OWNER TO \\"postgres\\"","CREATE OR REPLACE FUNCTION \\"public\\".\\"update_search_term_status\\"(\\"term_id\\" bigint, \\"status\\" \\"text\\", \\"email_count\\" integer) RETURNS \\"void\\"\n    LANGUAGE \\"plpgsql\\"\n    AS $$\nBEGIN\n    UPDATE search_terms\n    SET status = status,\n        last_processed_at = CURRENT_TIMESTAMP,\n        fetched_emails = email_count\n    WHERE id = term_id;\nEND;\n$$","ALTER FUNCTION \\"public\\".\\"update_search_term_status\\"(\\"term_id\\" bigint, \\"status\\" \\"text\\", \\"email_count\\" integer) OWNER TO \\"postgres\\"","SET default_tablespace = ''","SET default_table_access_method = \\"heap\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"ai_request_logs\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"function_name\\" \\"text\\",\n    \\"prompt\\" \\"text\\",\n    \\"response\\" \\"text\\",\n    \\"model_used\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"lead_id\\" bigint,\n    \\"email_campaign_id\\" bigint\n)","ALTER TABLE \\"public\\".\\"ai_request_logs\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"ai_request_logs_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"ai_request_logs_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"ai_request_logs_id_seq\\" OWNED BY \\"public\\".\\"ai_request_logs\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"ai_requests\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"function_name\\" \\"text\\",\n    \\"prompt\\" \\"text\\",\n    \\"response\\" \\"text\\",\n    \\"lead_id\\" bigint,\n    \\"email_campaign_id\\" bigint,\n    \\"model_used\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"logs\\" \\"json\\"\n)","ALTER TABLE \\"public\\".\\"ai_requests\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"ai_requests_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"ai_requests_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"ai_requests_id_seq\\" OWNED BY \\"public\\".\\"ai_requests\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"alembic_version\\" (\n    \\"version_num\\" character varying(32) NOT NULL\n)","ALTER TABLE \\"public\\".\\"alembic_version\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_errors\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"task_type\\" \\"text\\",\n    \\"error_type\\" \\"text\\",\n    \\"error_message\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"automation_errors\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_errors_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_errors_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_errors_id_seq\\" OWNED BY \\"public\\".\\"automation_errors\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_jobs\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"status\\" character varying(50) NOT NULL,\n    \\"current_group\\" character varying(255),\n    \\"current_position\\" integer,\n    \\"total_emails_sent\\" integer DEFAULT 0,\n    \\"group_emails_sent\\" integer DEFAULT 0,\n    \\"distribution_method\\" character varying(50),\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"loop_interval\\" integer,\n    \\"max_emails_per_group\\" integer,\n    \\"loop_automation\\" boolean DEFAULT false\n)","ALTER TABLE \\"public\\".\\"automation_jobs\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_logs\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"campaign_id\\" bigint,\n    \\"search_term_id\\" bigint,\n    \\"leads_gathered\\" bigint,\n    \\"emails_sent\\" bigint,\n    \\"start_time\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"end_time\\" timestamp with time zone,\n    \\"status\\" \\"text\\",\n    \\"logs\\" \\"json\\"\n)","ALTER TABLE \\"public\\".\\"automation_logs\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_logs_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_logs_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_logs_id_seq\\" OWNED BY \\"public\\".\\"automation_logs\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_rules\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"name\\" \\"text\\",\n    \\"rule_type\\" \\"text\\",\n    \\"condition\\" \\"text\\",\n    \\"threshold\\" double precision,\n    \\"action\\" \\"text\\",\n    \\"notification_email\\" \\"text\\",\n    \\"is_active\\" boolean,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"automation_rules\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_rules_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_rules_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_rules_id_seq\\" OWNED BY \\"public\\".\\"automation_rules\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_schedules\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"name\\" \\"text\\",\n    \\"task_type\\" \\"text\\",\n    \\"frequency\\" \\"text\\",\n    \\"start_date\\" timestamp with time zone,\n    \\"end_date\\" timestamp with time zone,\n    \\"time_of_day\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"automation_schedules\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_schedules_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_schedules_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_schedules_id_seq\\" OWNED BY \\"public\\".\\"automation_schedules\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_settings\\" (\n    \\"id\\" integer NOT NULL,\n    \\"status\\" \\"text\\" DEFAULT 'stopped'::\\"text\\",\n    \\"distribution_method\\" \\"text\\" DEFAULT 'equitable'::\\"text\\",\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"automation_settings\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_settings_id_seq\\"\n    AS integer\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_settings_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_settings_id_seq\\" OWNED BY \\"public\\".\\"automation_settings\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_state\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"current_group_id\\" bigint,\n    \\"current_term_id\\" bigint,\n    \\"processed_groups\\" \\"jsonb\\" DEFAULT '[]'::\\"jsonb\\",\n    \\"group_metrics\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"term_metrics\\" \\"jsonb\\" DEFAULT '{}'::\\"jsonb\\",\n    \\"emails_sent\\" bigint DEFAULT 0,\n    \\"leads_found\\" bigint DEFAULT 0,\n    \\"last_updated\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"automation_state\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_state_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_state_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_state_id_seq\\" OWNED BY \\"public\\".\\"automation_state\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_status\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"status\\" \\"text\\",\n    \\"started_at\\" timestamp with time zone,\n    \\"stopped_at\\" timestamp with time zone,\n    \\"paused_at\\" timestamp with time zone,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"automation_status\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_status_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_status_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_status_id_seq\\" OWNED BY \\"public\\".\\"automation_status\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"automation_tasks\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"task_type\\" \\"text\\",\n    \\"status\\" \\"text\\",\n    \\"progress\\" integer,\n    \\"started_at\\" timestamp with time zone,\n    \\"completed_at\\" timestamp with time zone,\n    \\"eta\\" timestamp with time zone,\n    \\"logs\\" \\"json\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"automation_tasks\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"automation_tasks_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"automation_tasks_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"automation_tasks_id_seq\\" OWNED BY \\"public\\".\\"automation_tasks\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"campaign_leads\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"campaign_id\\" bigint,\n    \\"lead_id\\" bigint,\n    \\"status\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"campaign_leads\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"campaign_leads_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"campaign_leads_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"campaign_leads_id_seq\\" OWNED BY \\"public\\".\\"campaign_leads\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"campaigns\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"campaign_name\\" \\"text\\",\n    \\"campaign_type\\" \\"text\\",\n    \\"project_id\\" bigint,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"auto_send\\" boolean,\n    \\"loop_automation\\" boolean,\n    \\"ai_customization\\" boolean,\n    \\"max_emails_per_group\\" bigint,\n    \\"loop_interval\\" bigint,\n    \\"schedule_config\\" \\"json\\",\n    \\"ab_test_config\\" \\"json\\",\n    \\"sequence_config\\" \\"json\\",\n    \\"status\\" \\"text\\",\n    \\"updated_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"progress\\" integer DEFAULT 0,\n    \\"total_tasks\\" integer DEFAULT 0,\n    \\"completed_tasks\\" integer DEFAULT 0\n)","ALTER TABLE \\"public\\".\\"campaigns\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"campaigns_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"campaigns_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"campaigns_id_seq\\" OWNED BY \\"public\\".\\"campaigns\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"email_campaigns\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"campaign_id\\" bigint,\n    \\"lead_id\\" bigint,\n    \\"template_id\\" bigint,\n    \\"customized_subject\\" \\"text\\",\n    \\"customized_content\\" \\"text\\",\n    \\"original_subject\\" \\"text\\",\n    \\"original_content\\" \\"text\\",\n    \\"status\\" \\"text\\",\n    \\"engagement_data\\" \\"json\\",\n    \\"message_id\\" \\"text\\",\n    \\"tracking_id\\" \\"text\\",\n    \\"sent_at\\" timestamp with time zone,\n    \\"ai_customized\\" boolean,\n    \\"opened_at\\" timestamp with time zone,\n    \\"clicked_at\\" timestamp with time zone,\n    \\"open_count\\" bigint,\n    \\"click_count\\" bigint\n)","ALTER TABLE \\"public\\".\\"email_campaigns\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"email_campaigns_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"email_campaigns_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"email_campaigns_id_seq\\" OWNED BY \\"public\\".\\"email_campaigns\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"email_quotas\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"email_settings_id\\" bigint,\n    \\"daily_sent\\" bigint,\n    \\"last_reset\\" timestamp with time zone\n)","ALTER TABLE \\"public\\".\\"email_quotas\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"email_quotas_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"email_quotas_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"email_quotas_id_seq\\" OWNED BY \\"public\\".\\"email_quotas\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"email_settings\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"name\\" \\"text\\" NOT NULL,\n    \\"email\\" \\"text\\" NOT NULL,\n    \\"provider\\" \\"text\\" NOT NULL,\n    \\"smtp_server\\" \\"text\\",\n    \\"smtp_port\\" bigint,\n    \\"smtp_username\\" \\"text\\",\n    \\"smtp_password\\" \\"text\\",\n    \\"aws_access_key_id\\" \\"text\\",\n    \\"aws_secret_access_key\\" \\"text\\",\n    \\"aws_region\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"email_settings\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"email_settings_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"email_settings_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"email_settings_id_seq\\" OWNED BY \\"public\\".\\"email_settings\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"email_templates\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"campaign_id\\" bigint,\n    \\"template_name\\" \\"text\\",\n    \\"subject\\" \\"text\\",\n    \\"body_content\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"is_ai_customizable\\" boolean,\n    \\"language\\" \\"text\\"\n)","ALTER TABLE \\"public\\".\\"email_templates\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"email_templates_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"email_templates_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"email_templates_id_seq\\" OWNED BY \\"public\\".\\"email_templates\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"knowledge_base\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"project_id\\" bigint NOT NULL,\n    \\"kb_name\\" \\"text\\",\n    \\"kb_bio\\" \\"text\\",\n    \\"kb_values\\" \\"text\\",\n    \\"contact_name\\" \\"text\\",\n    \\"contact_role\\" \\"text\\",\n    \\"contact_email\\" \\"text\\",\n    \\"company_description\\" \\"text\\",\n    \\"company_mission\\" \\"text\\",\n    \\"company_target_market\\" \\"text\\",\n    \\"company_other\\" \\"text\\",\n    \\"product_name\\" \\"text\\",\n    \\"product_description\\" \\"text\\",\n    \\"product_target_customer\\" \\"text\\",\n    \\"product_other\\" \\"text\\",\n    \\"other_context\\" \\"text\\",\n    \\"example_email\\" \\"text\\",\n    \\"tone_of_voice\\" \\"text\\",\n    \\"communication_style\\" \\"text\\",\n    \\"response_templates\\" \\"json\\",\n    \\"keywords\\" \\"json\\",\n    \\"context_variables\\" \\"json\\",\n    \\"ai_customization_rules\\" \\"json\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone\n)","ALTER TABLE \\"public\\".\\"knowledge_base\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"knowledge_base_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"knowledge_base_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"knowledge_base_id_seq\\" OWNED BY \\"public\\".\\"knowledge_base\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"lead_sources\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"lead_id\\" bigint,\n    \\"search_term_id\\" bigint,\n    \\"url\\" \\"text\\",\n    \\"domain\\" \\"text\\",\n    \\"page_title\\" \\"text\\",\n    \\"meta_description\\" \\"text\\",\n    \\"scrape_duration\\" \\"text\\",\n    \\"meta_tags\\" \\"text\\",\n    \\"phone_numbers\\" \\"text\\",\n    \\"content\\" \\"text\\",\n    \\"tags\\" \\"text\\",\n    \\"http_status\\" bigint,\n    \\"domain_effectiveness\\" \\"json\\",\n    \\"correlation_data\\" \\"json\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"lead_sources\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"lead_sources_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"lead_sources_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"lead_sources_id_seq\\" OWNED BY \\"public\\".\\"lead_sources\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"leads\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"email\\" \\"text\\",\n    \\"phone\\" \\"text\\",\n    \\"first_name\\" \\"text\\",\n    \\"last_name\\" \\"text\\",\n    \\"company\\" \\"text\\",\n    \\"job_title\\" \\"text\\",\n    \\"lead_score\\" bigint,\n    \\"status\\" \\"text\\",\n    \\"source_category\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"is_processed\\" boolean DEFAULT false\n)","ALTER TABLE \\"public\\".\\"leads\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"leads_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"leads_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"leads_id_seq\\" OWNED BY \\"public\\".\\"leads\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"optimized_search_terms\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"original_term_id\\" bigint,\n    \\"term\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"optimized_search_terms\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"optimized_search_terms_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"optimized_search_terms_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"optimized_search_terms_id_seq\\" OWNED BY \\"public\\".\\"optimized_search_terms\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"projects\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"project_name\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"projects\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"projects_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"projects_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"projects_id_seq\\" OWNED BY \\"public\\".\\"projects\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"search_groups\\" (\n    \\"id\\" \\"uuid\\" DEFAULT \\"extensions\\".\\"uuid_generate_v4\\"() NOT NULL,\n    \\"name\\" character varying(255) NOT NULL,\n    \\"description\\" \\"text\\",\n    \\"emails_sent\\" integer DEFAULT 0,\n    \\"created_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp with time zone DEFAULT CURRENT_TIMESTAMP\n)","ALTER TABLE \\"public\\".\\"search_groups\\" OWNER TO \\"postgres\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"search_processes\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"search_terms\\" \\"json\\",\n    \\"settings\\" \\"json\\",\n    \\"status\\" \\"text\\",\n    \\"results\\" \\"json\\",\n    \\"logs\\" \\"json\\",\n    \\"total_leads_found\\" bigint,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"updated_at\\" timestamp with time zone,\n    \\"campaign_id\\" bigint\n)","ALTER TABLE \\"public\\".\\"search_processes\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"search_processes_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"search_processes_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"search_processes_id_seq\\" OWNED BY \\"public\\".\\"search_processes\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"search_term_effectiveness\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"search_term_id\\" bigint,\n    \\"total_results\\" bigint,\n    \\"valid_leads\\" bigint,\n    \\"irrelevant_leads\\" bigint,\n    \\"blogs_found\\" bigint,\n    \\"directories_found\\" bigint,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"search_term_effectiveness\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"search_term_effectiveness_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"search_term_effectiveness_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"search_term_effectiveness_id_seq\\" OWNED BY \\"public\\".\\"search_term_effectiveness\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"search_term_groups\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"name\\" \\"text\\",\n    \\"email_template\\" \\"text\\",\n    \\"description\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"search_term_groups\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"search_term_groups_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"search_term_groups_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"search_term_groups_id_seq\\" OWNED BY \\"public\\".\\"search_term_groups\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"search_terms\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"campaign_id\\" bigint,\n    \\"term\\" \\"text\\",\n    \\"category\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"language\\" \\"text\\",\n    \\"group_id\\" bigint,\n    \\"new_column_name\\" \\"text\\"\n)","ALTER TABLE \\"public\\".\\"search_terms\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"search_terms_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"search_terms_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"search_terms_id_seq\\" OWNED BY \\"public\\".\\"search_terms\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"settings\\" (\n    \\"id\\" integer NOT NULL,\n    \\"category\\" \\"text\\" NOT NULL,\n    \\"key\\" \\"text\\" NOT NULL,\n    \\"value\\" \\"text\\",\n    \\"is_secret\\" boolean DEFAULT false,\n    \\"description\\" \\"text\\",\n    \\"created_at\\" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,\n    \\"updated_at\\" timestamp without time zone\n)","ALTER TABLE \\"public\\".\\"settings\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"settings_id_seq\\"\n    AS integer\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"settings_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"settings_id_seq\\" OWNED BY \\"public\\".\\"settings\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"users\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"username\\" \\"text\\" NOT NULL,\n    \\"email\\" \\"text\\" NOT NULL,\n    \\"password_hash\\" \\"text\\" NOT NULL,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"users\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"users_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"users_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"users_id_seq\\" OWNED BY \\"public\\".\\"users\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"webhook_logs\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"webhook_id\\" bigint,\n    \\"event\\" \\"text\\",\n    \\"payload\\" \\"json\\",\n    \\"response_status\\" bigint,\n    \\"response_body\\" \\"text\\",\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"()\n)","ALTER TABLE \\"public\\".\\"webhook_logs\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"webhook_logs_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"webhook_logs_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"webhook_logs_id_seq\\" OWNED BY \\"public\\".\\"webhook_logs\\".\\"id\\"","CREATE TABLE IF NOT EXISTS \\"public\\".\\"webhooks\\" (\n    \\"id\\" bigint NOT NULL,\n    \\"project_id\\" bigint,\n    \\"name\\" \\"text\\" NOT NULL,\n    \\"url\\" \\"text\\" NOT NULL,\n    \\"secret_key\\" \\"text\\",\n    \\"events\\" \\"json\\",\n    \\"is_active\\" boolean,\n    \\"created_at\\" timestamp with time zone DEFAULT \\"now\\"(),\n    \\"last_triggered\\" timestamp with time zone\n)","ALTER TABLE \\"public\\".\\"webhooks\\" OWNER TO \\"postgres\\"","CREATE SEQUENCE IF NOT EXISTS \\"public\\".\\"webhooks_id_seq\\"\n    START WITH 1\n    INCREMENT BY 1\n    NO MINVALUE\n    NO MAXVALUE\n    CACHE 1","ALTER TABLE \\"public\\".\\"webhooks_id_seq\\" OWNER TO \\"postgres\\"","ALTER SEQUENCE \\"public\\".\\"webhooks_id_seq\\" OWNED BY \\"public\\".\\"webhooks\\".\\"id\\"","ALTER TABLE ONLY \\"public\\".\\"ai_request_logs\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"ai_request_logs_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"ai_requests\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"ai_requests_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_errors\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_errors_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_logs\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_logs_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_rules\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_rules_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_schedules\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_schedules_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_settings\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_settings_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_state\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_state_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_status\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_status_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"automation_tasks\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"automation_tasks_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"campaign_leads\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"campaign_leads_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"campaigns\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"campaigns_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"email_campaigns\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"email_campaigns_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"email_quotas\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"email_quotas_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"email_settings\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"email_settings_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"email_templates\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"email_templates_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"knowledge_base\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"knowledge_base_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"lead_sources\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"lead_sources_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"leads\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"leads_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"optimized_search_terms\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"optimized_search_terms_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"projects_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"search_processes\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"search_processes_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"search_term_effectiveness\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"search_term_effectiveness_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"search_term_groups\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"search_term_groups_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"search_terms\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"search_terms_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"settings\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"settings_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"users\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"users_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"webhook_logs\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"webhook_logs_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"webhooks\\" ALTER COLUMN \\"id\\" SET DEFAULT \\"nextval\\"('\\"public\\".\\"webhooks_id_seq\\"'::\\"regclass\\")","ALTER TABLE ONLY \\"public\\".\\"ai_request_logs\\"\n    ADD CONSTRAINT \\"ai_request_logs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"ai_requests\\"\n    ADD CONSTRAINT \\"ai_requests_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"alembic_version\\"\n    ADD CONSTRAINT \\"alembic_version_pkc\\" PRIMARY KEY (\\"version_num\\")","ALTER TABLE ONLY \\"public\\".\\"automation_errors\\"\n    ADD CONSTRAINT \\"automation_errors_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_jobs\\"\n    ADD CONSTRAINT \\"automation_jobs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_logs\\"\n    ADD CONSTRAINT \\"automation_logs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_rules\\"\n    ADD CONSTRAINT \\"automation_rules_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_schedules\\"\n    ADD CONSTRAINT \\"automation_schedules_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_settings\\"\n    ADD CONSTRAINT \\"automation_settings_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_state\\"\n    ADD CONSTRAINT \\"automation_state_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_status\\"\n    ADD CONSTRAINT \\"automation_status_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_tasks\\"\n    ADD CONSTRAINT \\"automation_tasks_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"campaign_leads\\"\n    ADD CONSTRAINT \\"campaign_leads_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"campaigns\\"\n    ADD CONSTRAINT \\"campaigns_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_campaigns\\"\n    ADD CONSTRAINT \\"email_campaigns_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_campaigns\\"\n    ADD CONSTRAINT \\"email_campaigns_tracking_id_key\\" UNIQUE (\\"tracking_id\\")","ALTER TABLE ONLY \\"public\\".\\"email_quotas\\"\n    ADD CONSTRAINT \\"email_quotas_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_settings\\"\n    ADD CONSTRAINT \\"email_settings_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_templates\\"\n    ADD CONSTRAINT \\"email_templates_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"knowledge_base\\"\n    ADD CONSTRAINT \\"knowledge_base_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"lead_sources\\"\n    ADD CONSTRAINT \\"lead_sources_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"leads\\"\n    ADD CONSTRAINT \\"leads_email_key\\" UNIQUE (\\"email\\")","ALTER TABLE ONLY \\"public\\".\\"leads\\"\n    ADD CONSTRAINT \\"leads_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"optimized_search_terms\\"\n    ADD CONSTRAINT \\"optimized_search_terms_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"projects\\"\n    ADD CONSTRAINT \\"projects_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_groups\\"\n    ADD CONSTRAINT \\"search_groups_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_processes\\"\n    ADD CONSTRAINT \\"search_processes_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_term_effectiveness\\"\n    ADD CONSTRAINT \\"search_term_effectiveness_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_term_groups\\"\n    ADD CONSTRAINT \\"search_term_groups_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_terms\\"\n    ADD CONSTRAINT \\"search_terms_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"settings\\"\n    ADD CONSTRAINT \\"settings_category_key_key\\" UNIQUE (\\"category\\", \\"key\\")","ALTER TABLE ONLY \\"public\\".\\"settings\\"\n    ADD CONSTRAINT \\"settings_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_email_key\\" UNIQUE (\\"email\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"users\\"\n    ADD CONSTRAINT \\"users_username_key\\" UNIQUE (\\"username\\")","ALTER TABLE ONLY \\"public\\".\\"webhook_logs\\"\n    ADD CONSTRAINT \\"webhook_logs_pkey\\" PRIMARY KEY (\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"webhooks\\"\n    ADD CONSTRAINT \\"webhooks_pkey\\" PRIMARY KEY (\\"id\\")","CREATE INDEX \\"idx_automation_logs_created_at\\" ON \\"public\\".\\"automation_logs\\" USING \\"btree\\" (\\"start_time\\" DESC)","CREATE INDEX \\"idx_search_process_created\\" ON \\"public\\".\\"search_processes\\" USING \\"btree\\" (\\"created_at\\")","CREATE INDEX \\"idx_search_process_status\\" ON \\"public\\".\\"search_processes\\" USING \\"btree\\" (\\"status\\")","ALTER TABLE ONLY \\"public\\".\\"ai_request_logs\\"\n    ADD CONSTRAINT \\"ai_request_logs_email_campaign_id_fkey\\" FOREIGN KEY (\\"email_campaign_id\\") REFERENCES \\"public\\".\\"email_campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"ai_request_logs\\"\n    ADD CONSTRAINT \\"ai_request_logs_lead_id_fkey\\" FOREIGN KEY (\\"lead_id\\") REFERENCES \\"public\\".\\"leads\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"ai_requests\\"\n    ADD CONSTRAINT \\"ai_requests_email_campaign_id_fkey\\" FOREIGN KEY (\\"email_campaign_id\\") REFERENCES \\"public\\".\\"email_campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"ai_requests\\"\n    ADD CONSTRAINT \\"ai_requests_lead_id_fkey\\" FOREIGN KEY (\\"lead_id\\") REFERENCES \\"public\\".\\"leads\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_logs\\"\n    ADD CONSTRAINT \\"automation_logs_campaign_id_fkey\\" FOREIGN KEY (\\"campaign_id\\") REFERENCES \\"public\\".\\"campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_logs\\"\n    ADD CONSTRAINT \\"automation_logs_search_term_id_fkey\\" FOREIGN KEY (\\"search_term_id\\") REFERENCES \\"public\\".\\"search_terms\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_state\\"\n    ADD CONSTRAINT \\"automation_state_current_group_id_fkey\\" FOREIGN KEY (\\"current_group_id\\") REFERENCES \\"public\\".\\"search_term_groups\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"automation_state\\"\n    ADD CONSTRAINT \\"automation_state_current_term_id_fkey\\" FOREIGN KEY (\\"current_term_id\\") REFERENCES \\"public\\".\\"search_terms\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"campaign_leads\\"\n    ADD CONSTRAINT \\"campaign_leads_campaign_id_fkey\\" FOREIGN KEY (\\"campaign_id\\") REFERENCES \\"public\\".\\"campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"campaign_leads\\"\n    ADD CONSTRAINT \\"campaign_leads_lead_id_fkey\\" FOREIGN KEY (\\"lead_id\\") REFERENCES \\"public\\".\\"leads\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"campaigns\\"\n    ADD CONSTRAINT \\"campaigns_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_campaigns\\"\n    ADD CONSTRAINT \\"email_campaigns_campaign_id_fkey\\" FOREIGN KEY (\\"campaign_id\\") REFERENCES \\"public\\".\\"campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_campaigns\\"\n    ADD CONSTRAINT \\"email_campaigns_lead_id_fkey\\" FOREIGN KEY (\\"lead_id\\") REFERENCES \\"public\\".\\"leads\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_campaigns\\"\n    ADD CONSTRAINT \\"email_campaigns_template_id_fkey\\" FOREIGN KEY (\\"template_id\\") REFERENCES \\"public\\".\\"email_templates\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_quotas\\"\n    ADD CONSTRAINT \\"email_quotas_email_settings_id_fkey\\" FOREIGN KEY (\\"email_settings_id\\") REFERENCES \\"public\\".\\"email_settings\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"email_templates\\"\n    ADD CONSTRAINT \\"email_templates_campaign_id_fkey\\" FOREIGN KEY (\\"campaign_id\\") REFERENCES \\"public\\".\\"campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_terms\\"\n    ADD CONSTRAINT \\"fk_search_terms_group\\" FOREIGN KEY (\\"group_id\\") REFERENCES \\"public\\".\\"search_term_groups\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"knowledge_base\\"\n    ADD CONSTRAINT \\"knowledge_base_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"lead_sources\\"\n    ADD CONSTRAINT \\"lead_sources_lead_id_fkey\\" FOREIGN KEY (\\"lead_id\\") REFERENCES \\"public\\".\\"leads\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"lead_sources\\"\n    ADD CONSTRAINT \\"lead_sources_search_term_id_fkey\\" FOREIGN KEY (\\"search_term_id\\") REFERENCES \\"public\\".\\"search_terms\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"optimized_search_terms\\"\n    ADD CONSTRAINT \\"optimized_search_terms_original_term_id_fkey\\" FOREIGN KEY (\\"original_term_id\\") REFERENCES \\"public\\".\\"search_terms\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_processes\\"\n    ADD CONSTRAINT \\"search_processes_campaign_id_fkey\\" FOREIGN KEY (\\"campaign_id\\") REFERENCES \\"public\\".\\"campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_term_effectiveness\\"\n    ADD CONSTRAINT \\"search_term_effectiveness_search_term_id_fkey\\" FOREIGN KEY (\\"search_term_id\\") REFERENCES \\"public\\".\\"search_terms\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"search_terms\\"\n    ADD CONSTRAINT \\"search_terms_campaign_id_fkey\\" FOREIGN KEY (\\"campaign_id\\") REFERENCES \\"public\\".\\"campaigns\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"webhook_logs\\"\n    ADD CONSTRAINT \\"webhook_logs_webhook_id_fkey\\" FOREIGN KEY (\\"webhook_id\\") REFERENCES \\"public\\".\\"webhooks\\"(\\"id\\")","ALTER TABLE ONLY \\"public\\".\\"webhooks\\"\n    ADD CONSTRAINT \\"webhooks_project_id_fkey\\" FOREIGN KEY (\\"project_id\\") REFERENCES \\"public\\".\\"projects\\"(\\"id\\")","CREATE POLICY \\"Allow authenticated users to delete from ai_request_logs\\" ON \\"public\\".\\"ai_request_logs\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from ai_requests\\" ON \\"public\\".\\"ai_requests\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from alembic_version\\" ON \\"public\\".\\"alembic_version\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_errors\\" ON \\"public\\".\\"automation_errors\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_jobs\\" ON \\"public\\".\\"automation_jobs\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_logs\\" ON \\"public\\".\\"automation_logs\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_rules\\" ON \\"public\\".\\"automation_rules\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_schedules\\" ON \\"public\\".\\"automation_schedules\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_settings\\" ON \\"public\\".\\"automation_settings\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_state\\" ON \\"public\\".\\"automation_state\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_status\\" ON \\"public\\".\\"automation_status\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from automation_tasks\\" ON \\"public\\".\\"automation_tasks\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from campaign_leads\\" ON \\"public\\".\\"campaign_leads\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from campaigns\\" ON \\"public\\".\\"campaigns\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from email_campaigns\\" ON \\"public\\".\\"email_campaigns\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from email_quotas\\" ON \\"public\\".\\"email_quotas\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from email_settings\\" ON \\"public\\".\\"email_settings\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from email_templates\\" ON \\"public\\".\\"email_templates\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from knowledge_base\\" ON \\"public\\".\\"knowledge_base\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from lead_sources\\" ON \\"public\\".\\"lead_sources\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from leads\\" ON \\"public\\".\\"leads\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from optimized_search_terms\\" ON \\"public\\".\\"optimized_search_terms\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from projects\\" ON \\"public\\".\\"projects\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from search_groups\\" ON \\"public\\".\\"search_groups\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from search_processes\\" ON \\"public\\".\\"search_processes\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from search_term_effectiven\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from search_term_groups\\" ON \\"public\\".\\"search_term_groups\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from search_terms\\" ON \\"public\\".\\"search_terms\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from settings\\" ON \\"public\\".\\"settings\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from tables\\" ON \\"public\\".\\"ai_request_logs\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from users\\" ON \\"public\\".\\"users\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from webhook_logs\\" ON \\"public\\".\\"webhook_logs\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to delete from webhooks\\" ON \\"public\\".\\"webhooks\\" FOR DELETE TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to insert into ai_request_logs\\" ON \\"public\\".\\"ai_request_logs\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into ai_requests\\" ON \\"public\\".\\"ai_requests\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into alembic_version\\" ON \\"public\\".\\"alembic_version\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_errors\\" ON \\"public\\".\\"automation_errors\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_jobs\\" ON \\"public\\".\\"automation_jobs\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_logs\\" ON \\"public\\".\\"automation_logs\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_rules\\" ON \\"public\\".\\"automation_rules\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_schedules\\" ON \\"public\\".\\"automation_schedules\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_settings\\" ON \\"public\\".\\"automation_settings\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_state\\" ON \\"public\\".\\"automation_state\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_status\\" ON \\"public\\".\\"automation_status\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into automation_tasks\\" ON \\"public\\".\\"automation_tasks\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into campaign_leads\\" ON \\"public\\".\\"campaign_leads\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into campaigns\\" ON \\"public\\".\\"campaigns\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into email_campaigns\\" ON \\"public\\".\\"email_campaigns\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into email_quotas\\" ON \\"public\\".\\"email_quotas\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into email_settings\\" ON \\"public\\".\\"email_settings\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into email_templates\\" ON \\"public\\".\\"email_templates\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into knowledge_base\\" ON \\"public\\".\\"knowledge_base\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into lead_sources\\" ON \\"public\\".\\"lead_sources\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into leads\\" ON \\"public\\".\\"leads\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into optimized_search_terms\\" ON \\"public\\".\\"optimized_search_terms\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into projects\\" ON \\"public\\".\\"projects\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into search_groups\\" ON \\"public\\".\\"search_groups\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into search_processes\\" ON \\"public\\".\\"search_processes\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into search_term_effectiven\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into search_term_groups\\" ON \\"public\\".\\"search_term_groups\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into search_terms\\" ON \\"public\\".\\"search_terms\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into settings\\" ON \\"public\\".\\"settings\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into tables\\" ON \\"public\\".\\"ai_request_logs\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into users\\" ON \\"public\\".\\"users\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into webhook_logs\\" ON \\"public\\".\\"webhook_logs\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to insert into webhooks\\" ON \\"public\\".\\"webhooks\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to select from ai_request_logs\\" ON \\"public\\".\\"ai_request_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from ai_requests\\" ON \\"public\\".\\"ai_requests\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from alembic_version\\" ON \\"public\\".\\"alembic_version\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_errors\\" ON \\"public\\".\\"automation_errors\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_jobs\\" ON \\"public\\".\\"automation_jobs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_logs\\" ON \\"public\\".\\"automation_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_rules\\" ON \\"public\\".\\"automation_rules\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_schedules\\" ON \\"public\\".\\"automation_schedules\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_settings\\" ON \\"public\\".\\"automation_settings\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_state\\" ON \\"public\\".\\"automation_state\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_status\\" ON \\"public\\".\\"automation_status\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from automation_tasks\\" ON \\"public\\".\\"automation_tasks\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from campaign_leads\\" ON \\"public\\".\\"campaign_leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from campaigns\\" ON \\"public\\".\\"campaigns\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from email_campaigns\\" ON \\"public\\".\\"email_campaigns\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from email_quotas\\" ON \\"public\\".\\"email_quotas\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from email_settings\\" ON \\"public\\".\\"email_settings\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from email_templates\\" ON \\"public\\".\\"email_templates\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from knowledge_base\\" ON \\"public\\".\\"knowledge_base\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from lead_sources\\" ON \\"public\\".\\"lead_sources\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from leads\\" ON \\"public\\".\\"leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from optimized_search_terms\\" ON \\"public\\".\\"optimized_search_terms\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from projects\\" ON \\"public\\".\\"projects\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from search_groups\\" ON \\"public\\".\\"search_groups\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from search_processes\\" ON \\"public\\".\\"search_processes\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from search_term_effectiven\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from search_term_groups\\" ON \\"public\\".\\"search_term_groups\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from search_terms\\" ON \\"public\\".\\"search_terms\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from settings\\" ON \\"public\\".\\"settings\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from tables\\" ON \\"public\\".\\"ai_request_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from users\\" ON \\"public\\".\\"users\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from webhook_logs\\" ON \\"public\\".\\"webhook_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to select from webhooks\\" ON \\"public\\".\\"webhooks\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Allow authenticated users to update ai_request_logs\\" ON \\"public\\".\\"ai_request_logs\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update ai_requests\\" ON \\"public\\".\\"ai_requests\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update alembic_version\\" ON \\"public\\".\\"alembic_version\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_errors\\" ON \\"public\\".\\"automation_errors\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_jobs\\" ON \\"public\\".\\"automation_jobs\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_logs\\" ON \\"public\\".\\"automation_logs\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_rules\\" ON \\"public\\".\\"automation_rules\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_schedules\\" ON \\"public\\".\\"automation_schedules\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_settings\\" ON \\"public\\".\\"automation_settings\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_state\\" ON \\"public\\".\\"automation_state\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_status\\" ON \\"public\\".\\"automation_status\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update automation_tasks\\" ON \\"public\\".\\"automation_tasks\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update campaign_leads\\" ON \\"public\\".\\"campaign_leads\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update campaigns\\" ON \\"public\\".\\"campaigns\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update email_campaigns\\" ON \\"public\\".\\"email_campaigns\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update email_quotas\\" ON \\"public\\".\\"email_quotas\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update email_settings\\" ON \\"public\\".\\"email_settings\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update email_templates\\" ON \\"public\\".\\"email_templates\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update knowledge_base\\" ON \\"public\\".\\"knowledge_base\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update lead_sources\\" ON \\"public\\".\\"lead_sources\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update leads\\" ON \\"public\\".\\"leads\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update optimized_search_terms\\" ON \\"public\\".\\"optimized_search_terms\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update projects\\" ON \\"public\\".\\"projects\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update search_groups\\" ON \\"public\\".\\"search_groups\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update search_processes\\" ON \\"public\\".\\"search_processes\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update search_term_effectiveness\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update search_term_groups\\" ON \\"public\\".\\"search_term_groups\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update search_terms\\" ON \\"public\\".\\"search_terms\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update settings\\" ON \\"public\\".\\"settings\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update tables\\" ON \\"public\\".\\"ai_request_logs\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update users\\" ON \\"public\\".\\"users\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update webhook_logs\\" ON \\"public\\".\\"webhook_logs\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Allow authenticated users to update webhooks\\" ON \\"public\\".\\"webhooks\\" FOR UPDATE TO \\"authenticated\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"ai_request_logs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"ai_requests\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"alembic_version\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_errors\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_jobs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_logs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_rules\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_schedules\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_settings\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_state\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_status\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"automation_tasks\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"campaign_leads\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"campaigns\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"email_campaigns\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"email_quotas\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"email_settings\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"email_templates\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"knowledge_base\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"lead_sources\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"leads\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"optimized_search_terms\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"projects\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"search_groups\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"search_processes\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"search_term_effectiveness\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"search_term_groups\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"search_terms\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"settings\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"users\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"webhook_logs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable all access for service role\\" ON \\"public\\".\\"webhooks\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"ai_request_logs\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"ai_requests\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"alembic_version\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_errors\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_jobs\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_logs\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_rules\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_schedules\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_settings\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_state\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_status\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"automation_tasks\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"campaign_leads\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"campaigns\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"email_campaigns\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"email_quotas\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"email_settings\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"email_templates\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"knowledge_base\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"lead_sources\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"leads\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"optimized_search_terms\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"projects\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"search_groups\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"search_processes\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"search_term_groups\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"search_terms\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"settings\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"users\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"webhook_logs\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete access for service role\\" ON \\"public\\".\\"webhooks\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable delete for all users\\" ON \\"public\\".\\"leads\\" FOR DELETE USING (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"ai_request_logs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"ai_requests\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"alembic_version\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_errors\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_jobs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_logs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_rules\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_schedules\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_settings\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_state\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_status\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"automation_tasks\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"campaign_leads\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"campaigns\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"email_campaigns\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"email_quotas\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"email_settings\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"email_templates\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"knowledge_base\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"lead_sources\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"leads\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"optimized_search_terms\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"projects\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"search_groups\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"search_processes\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"search_term_effectiveness\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"search_term_groups\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"search_terms\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"settings\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"users\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"webhook_logs\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable full access for service role\\" ON \\"public\\".\\"webhooks\\" TO \\"service_role\\" USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable insert access for authenticated users\\" ON \\"public\\".\\"leads\\" FOR INSERT TO \\"authenticated\\" WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"ai_request_logs\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"ai_requests\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"alembic_version\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_errors\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_jobs\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_logs\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_rules\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_schedules\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_settings\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_state\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_status\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"automation_tasks\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"campaign_leads\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"campaigns\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"email_campaigns\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"email_quotas\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"email_settings\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"email_templates\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"knowledge_base\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"lead_sources\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"leads\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"optimized_search_terms\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"projects\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"search_groups\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"search_processes\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"search_term_groups\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"search_terms\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"settings\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"users\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"webhook_logs\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert access for service role\\" ON \\"public\\".\\"webhooks\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert for all users\\" ON \\"public\\".\\"leads\\" FOR INSERT WITH CHECK (true)","CREATE POLICY \\"Enable insert for service role\\" ON \\"public\\".\\"leads\\" FOR INSERT TO \\"service_role\\" WITH CHECK (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"ai_request_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"ai_requests\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"alembic_version\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_errors\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_jobs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_rules\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_schedules\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_settings\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_state\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_status\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"automation_tasks\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"campaign_leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"campaigns\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"email_campaigns\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"email_quotas\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"email_settings\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"email_templates\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"knowledge_base\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"lead_sources\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"optimized_search_terms\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"projects\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"search_groups\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"search_processes\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"search_term_groups\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"search_terms\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"settings\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"users\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"webhook_logs\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all\\" ON \\"public\\".\\"webhooks\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all authenticated users\\" ON \\"public\\".\\"leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for all users\\" ON \\"public\\".\\"leads\\" FOR SELECT USING (true)","CREATE POLICY \\"Enable read access for anonymous users\\" ON \\"public\\".\\"leads\\" FOR SELECT TO \\"anon\\" USING (true)","CREATE POLICY \\"Enable read access for authenticated users\\" ON \\"public\\".\\"knowledge_base\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for authenticated users\\" ON \\"public\\".\\"leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for authenticated users\\" ON \\"public\\".\\"projects\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read access for authenticated users\\" ON \\"public\\".\\"search_terms\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read for authenticated users\\" ON \\"public\\".\\"leads\\" FOR SELECT TO \\"authenticated\\" USING (true)","CREATE POLICY \\"Enable read for authenticated users\\" ON \\"public\\".\\"settings\\" FOR SELECT TO \\"authenticated\\" USING ((NOT \\"is_secret\\"))","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"ai_request_logs\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"ai_requests\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"alembic_version\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_errors\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_jobs\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_logs\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_rules\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_schedules\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_settings\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_state\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_status\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"automation_tasks\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"campaign_leads\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"campaigns\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"email_campaigns\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"email_quotas\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"email_settings\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"email_templates\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"knowledge_base\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"lead_sources\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"leads\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"optimized_search_terms\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"projects\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"search_groups\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"search_processes\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"search_term_effectiveness\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"search_term_groups\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"search_terms\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"settings\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"users\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"webhook_logs\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update access for service role\\" ON \\"public\\".\\"webhooks\\" FOR UPDATE USING (true)","CREATE POLICY \\"Enable update for all users\\" ON \\"public\\".\\"leads\\" FOR UPDATE USING (true) WITH CHECK (true)","CREATE POLICY \\"Enable update for service role\\" ON \\"public\\".\\"leads\\" FOR UPDATE TO \\"service_role\\" USING (true)","ALTER TABLE \\"public\\".\\"ai_request_logs\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"ai_requests\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"alembic_version\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_errors\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_jobs\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_logs\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_rules\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_schedules\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_settings\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_state\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_status\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"automation_tasks\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"campaign_leads\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"campaigns\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"email_campaigns\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"email_quotas\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"email_settings\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"email_templates\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"knowledge_base\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"lead_sources\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"leads\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"optimized_search_terms\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"projects\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"search_groups\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"search_processes\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"search_term_effectiveness\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"search_term_groups\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"search_terms\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"settings\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"users\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"webhook_logs\\" ENABLE ROW LEVEL SECURITY","ALTER TABLE \\"public\\".\\"webhooks\\" ENABLE ROW LEVEL SECURITY","ALTER PUBLICATION \\"supabase_realtime\\" OWNER TO \\"postgres\\"","ALTER PUBLICATION \\"supabase_realtime\\" ADD TABLE ONLY \\"public\\".\\"leads\\"","REVOKE USAGE ON SCHEMA \\"public\\" FROM PUBLIC","GRANT USAGE ON SCHEMA \\"public\\" TO \\"service_role\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"anon\\"","GRANT USAGE ON SCHEMA \\"public\\" TO \\"authenticated\\"","GRANT ALL ON TABLE \\"public\\".\\"ai_request_logs\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"ai_request_logs_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"ai_requests\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"ai_requests_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"alembic_version\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_errors\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_errors_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_jobs\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_logs\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_logs_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_rules\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_rules_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_schedules\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_schedules_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_settings\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_settings_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_state\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_state_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_status\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_status_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"automation_tasks\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"automation_tasks_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"campaign_leads\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"campaign_leads_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"campaigns\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"campaigns_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"email_campaigns\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"email_campaigns_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"email_quotas\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"email_quotas_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"email_settings\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"email_settings_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"email_templates\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"email_templates_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"knowledge_base\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"knowledge_base_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"lead_sources\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"lead_sources_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"leads\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"leads_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"optimized_search_terms\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"optimized_search_terms_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"projects\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"projects_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"search_groups\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"search_processes\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"search_processes_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"search_term_effectiveness\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"search_term_effectiveness_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"search_term_groups\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"search_term_groups_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"search_terms\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"search_terms_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"settings\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"settings_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"users\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"users_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"webhook_logs\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"webhook_logs_id_seq\\" TO \\"service_role\\"","GRANT ALL ON TABLE \\"public\\".\\"webhooks\\" TO \\"service_role\\"","GRANT ALL ON SEQUENCE \\"public\\".\\"webhooks_id_seq\\" TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON SEQUENCES  TO \\"service_role\\"","ALTER DEFAULT PRIVILEGES FOR ROLE \\"postgres\\" IN SCHEMA \\"public\\" GRANT ALL ON TABLES  TO \\"service_role\\"","RESET ALL"}	remote_schema
\.


--
-- TOC entry 3884 (class 0 OID 29333)
-- Dependencies: 258
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
989e8d44-de6f-4c87-80ff-9fd8b4b0c8c8	OpenAI		nOUeDHAISpkJ/qjx8ZUQFhvdjjksja6iIZhUJpwY57G8hYMuYjRO7hE7AszN4J/JCmoXw3KF4ZLE\nzDUqs9fFfzG1bgyYz6lvStsfjHwWarvM+wmhose1edHnp+0wu4ysSTepzx0Tob/PQIzmlKswTV3H\nmndqLlXITzS2Qe12zN4YCVufH35TJQZiENdVIl/uIG19TTMKc0s4VnCip42SlWnO4+G0X6jIPpah\nOS8J/8+0ZOeukSxaVeGGlPkUcDl/U9CP5w==	26dd0c40-de79-4658-93cc-7fc109b3e7a0	\\xd5c483ec06004143a64670a2b148c7da	2024-09-20 05:15:27.454502+00	2024-09-20 05:15:27.454502+00
\.


--
-- TOC entry 4715 (class 0 OID 0)
-- Dependencies: 272
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- TOC entry 4716 (class 0 OID 0)
-- Dependencies: 299
-- Name: jobid_seq; Type: SEQUENCE SET; Schema: cron; Owner: supabase_admin
--

SELECT pg_catalog.setval('cron.jobid_seq', 1, false);


--
-- TOC entry 4717 (class 0 OID 0)
-- Dependencies: 301
-- Name: runid_seq; Type: SEQUENCE SET; Schema: cron; Owner: supabase_admin
--

SELECT pg_catalog.setval('cron.runid_seq', 1, false);


--
-- TOC entry 4718 (class 0 OID 0)
-- Dependencies: 249
-- Name: key_key_id_seq; Type: SEQUENCE SET; Schema: pgsodium; Owner: supabase_admin
--

SELECT pg_catalog.setval('pgsodium.key_key_id_seq', 1, true);


--
-- TOC entry 4719 (class 0 OID 0)
-- Dependencies: 327
-- Name: ai_request_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_request_logs_id_seq', 1, false);


--
-- TOC entry 4720 (class 0 OID 0)
-- Dependencies: 329
-- Name: automation_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.automation_logs_id_seq', 1, false);


--
-- TOC entry 4721 (class 0 OID 0)
-- Dependencies: 333
-- Name: background_process_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.background_process_state_id_seq', 5, true);


--
-- TOC entry 4722 (class 0 OID 0)
-- Dependencies: 313
-- Name: campaign_leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaign_leads_id_seq', 73, true);


--
-- TOC entry 4723 (class 0 OID 0)
-- Dependencies: 342
-- Name: campaign_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaign_metrics_id_seq', 1, false);


--
-- TOC entry 4724 (class 0 OID 0)
-- Dependencies: 307
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaigns_id_seq', 1, true);


--
-- TOC entry 4725 (class 0 OID 0)
-- Dependencies: 317
-- Name: email_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_campaigns_id_seq', 1, false);


--
-- TOC entry 4726 (class 0 OID 0)
-- Dependencies: 331
-- Name: email_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_settings_id_seq', 2, true);


--
-- TOC entry 4727 (class 0 OID 0)
-- Dependencies: 311
-- Name: email_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_templates_id_seq', 1, true);


--
-- TOC entry 4728 (class 0 OID 0)
-- Dependencies: 340
-- Name: error_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.error_events_id_seq', 22, true);


--
-- TOC entry 4729 (class 0 OID 0)
-- Dependencies: 309
-- Name: knowledge_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knowledge_base_id_seq', 1, false);


--
-- TOC entry 4730 (class 0 OID 0)
-- Dependencies: 319
-- Name: lead_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_sources_id_seq', 73, true);


--
-- TOC entry 4731 (class 0 OID 0)
-- Dependencies: 305
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leads_id_seq', 10, true);


--
-- TOC entry 4732 (class 0 OID 0)
-- Dependencies: 335
-- Name: optimized_search_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.optimized_search_terms_id_seq', 1, false);


--
-- TOC entry 4733 (class 0 OID 0)
-- Dependencies: 303
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, true);


--
-- TOC entry 4734 (class 0 OID 0)
-- Dependencies: 338
-- Name: search_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_logs_id_seq', 1, false);


--
-- TOC entry 4735 (class 0 OID 0)
-- Dependencies: 323
-- Name: search_term_effectiveness_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_term_effectiveness_id_seq', 1, false);


--
-- TOC entry 4736 (class 0 OID 0)
-- Dependencies: 321
-- Name: search_term_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_term_groups_id_seq', 1, false);


--
-- TOC entry 4737 (class 0 OID 0)
-- Dependencies: 315
-- Name: search_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.search_terms_id_seq', 1, true);


--
-- TOC entry 4738 (class 0 OID 0)
-- Dependencies: 325
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- TOC entry 4739 (class 0 OID 0)
-- Dependencies: 282
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 11104, true);


--
-- TOC entry 4740 (class 0 OID 0)
-- Dependencies: 289
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: supabase_functions_admin
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4050 (class 2606 OID 16842)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 16843)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4038 (class 2606 OID 16844)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4043 (class 2606 OID 16845)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4045 (class 2606 OID 16846)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 4048 (class 2606 OID 16847)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4052 (class 2606 OID 16848)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4055 (class 2606 OID 16849)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 16850)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4060 (class 2606 OID 16851)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4065 (class 2606 OID 16852)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4073 (class 2606 OID 16853)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4076 (class 2606 OID 16854)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4079 (class 2606 OID 16855)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4081 (class 2606 OID 16856)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4086 (class 2606 OID 16857)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 4089 (class 2606 OID 16858)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4092 (class 2606 OID 16859)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4097 (class 2606 OID 16860)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4100 (class 2606 OID 16861)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4112 (class 2606 OID 16862)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 4114 (class 2606 OID 16863)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4197 (class 2606 OID 181340)
-- Name: ai_request_logs ai_request_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_request_logs
    ADD CONSTRAINT ai_request_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4199 (class 2606 OID 181349)
-- Name: automation_logs automation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.automation_logs
    ADD CONSTRAINT automation_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4203 (class 2606 OID 181368)
-- Name: background_process_state background_process_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_process_state
    ADD CONSTRAINT background_process_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4205 (class 2606 OID 181370)
-- Name: background_process_state background_process_state_process_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_process_state
    ADD CONSTRAINT background_process_state_process_id_key UNIQUE (process_id);


--
-- TOC entry 4177 (class 2606 OID 181221)
-- Name: campaign_leads campaign_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_leads
    ADD CONSTRAINT campaign_leads_pkey PRIMARY KEY (id);


--
-- TOC entry 4215 (class 2606 OID 181414)
-- Name: campaign_metrics campaign_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_metrics
    ADD CONSTRAINT campaign_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4171 (class 2606 OID 181176)
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 4181 (class 2606 OID 181255)
-- Name: email_campaigns email_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 4183 (class 2606 OID 181257)
-- Name: email_campaigns email_campaigns_tracking_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_tracking_id_key UNIQUE (tracking_id);


--
-- TOC entry 4201 (class 2606 OID 181358)
-- Name: email_settings email_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_settings
    ADD CONSTRAINT email_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4175 (class 2606 OID 181206)
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4213 (class 2606 OID 181405)
-- Name: error_events error_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.error_events
    ADD CONSTRAINT error_events_pkey PRIMARY KEY (id);


--
-- TOC entry 4173 (class 2606 OID 181191)
-- Name: knowledge_base knowledge_base_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_pkey PRIMARY KEY (id);


--
-- TOC entry 4185 (class 2606 OID 181282)
-- Name: lead_sources lead_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT lead_sources_pkey PRIMARY KEY (id);


--
-- TOC entry 4167 (class 2606 OID 181166)
-- Name: leads leads_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_email_key UNIQUE (email);


--
-- TOC entry 4169 (class 2606 OID 181164)
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- TOC entry 4207 (class 2606 OID 181379)
-- Name: optimized_search_terms optimized_search_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.optimized_search_terms
    ADD CONSTRAINT optimized_search_terms_pkey PRIMARY KEY (id);


--
-- TOC entry 4165 (class 2606 OID 181154)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 4209 (class 2606 OID 181386)
-- Name: search_groups search_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_groups
    ADD CONSTRAINT search_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 4211 (class 2606 OID 181396)
-- Name: search_logs search_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_logs
    ADD CONSTRAINT search_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4191 (class 2606 OID 181312)
-- Name: search_term_effectiveness search_term_effectiveness_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_term_effectiveness
    ADD CONSTRAINT search_term_effectiveness_pkey PRIMARY KEY (id);


--
-- TOC entry 4189 (class 2606 OID 181304)
-- Name: search_term_groups search_term_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_term_groups
    ADD CONSTRAINT search_term_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 4179 (class 2606 OID 181241)
-- Name: search_terms search_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_terms
    ADD CONSTRAINT search_terms_pkey PRIMARY KEY (id);


--
-- TOC entry 4195 (class 2606 OID 181327)
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4145 (class 2606 OID 16904)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4147 (class 2606 OID 16905)
-- Name: messages_2024_12_23 messages_2024_12_23_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2024_12_23
    ADD CONSTRAINT messages_2024_12_23_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4149 (class 2606 OID 16906)
-- Name: messages_2024_12_24 messages_2024_12_24_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2024_12_24
    ADD CONSTRAINT messages_2024_12_24_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4151 (class 2606 OID 16907)
-- Name: messages_2024_12_25 messages_2024_12_25_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2024_12_25
    ADD CONSTRAINT messages_2024_12_25_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4153 (class 2606 OID 16908)
-- Name: messages_2024_12_26 messages_2024_12_26_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2024_12_26
    ADD CONSTRAINT messages_2024_12_26_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4157 (class 2606 OID 16909)
-- Name: messages_2024_12_27 messages_2024_12_27_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.messages_2024_12_27
    ADD CONSTRAINT messages_2024_12_27_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4119 (class 2606 OID 16910)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4116 (class 2606 OID 16911)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4123 (class 2606 OID 16912)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4125 (class 2606 OID 16913)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4127 (class 2606 OID 16914)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4132 (class 2606 OID 16915)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 16916)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4135 (class 2606 OID 16917)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4139 (class 2606 OID 16918)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4143 (class 2606 OID 16919)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: supabase_functions_admin
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4155 (class 2606 OID 16920)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4035 (class 1259 OID 29729)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 4102 (class 1259 OID 29730)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4103 (class 1259 OID 29731)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4104 (class 1259 OID 29732)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4056 (class 1259 OID 29733)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4036 (class 1259 OID 29734)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4041 (class 1259 OID 29735)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4741 (class 0 OID 0)
-- Dependencies: 4041
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4046 (class 1259 OID 29736)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4039 (class 1259 OID 29737)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4040 (class 1259 OID 29738)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4053 (class 1259 OID 29739)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4061 (class 1259 OID 29740)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4062 (class 1259 OID 29741)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4066 (class 1259 OID 29742)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4067 (class 1259 OID 29743)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4068 (class 1259 OID 29744)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 4105 (class 1259 OID 29745)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4106 (class 1259 OID 29746)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4069 (class 1259 OID 29747)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 4070 (class 1259 OID 29748)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 4071 (class 1259 OID 29749)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 4074 (class 1259 OID 29750)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 4077 (class 1259 OID 29751)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4082 (class 1259 OID 29752)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4083 (class 1259 OID 29753)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4084 (class 1259 OID 29754)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4087 (class 1259 OID 29755)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4090 (class 1259 OID 29756)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4093 (class 1259 OID 29757)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4095 (class 1259 OID 29758)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4098 (class 1259 OID 29759)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4101 (class 1259 OID 29760)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4063 (class 1259 OID 29953)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4094 (class 1259 OID 29761)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 4107 (class 1259 OID 29762)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4742 (class 0 OID 0)
-- Dependencies: 4107
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 4108 (class 1259 OID 29763)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 4109 (class 1259 OID 29764)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 4110 (class 1259 OID 29765)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4186 (class 1259 OID 181329)
-- Name: idx_group_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_created ON public.search_term_groups USING btree (created_at);


--
-- TOC entry 4187 (class 1259 OID 181328)
-- Name: idx_group_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_name ON public.search_term_groups USING btree (name);


--
-- TOC entry 4192 (class 1259 OID 181331)
-- Name: idx_settings_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_settings_name ON public.settings USING btree (name);


--
-- TOC entry 4193 (class 1259 OID 181330)
-- Name: idx_settings_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_settings_type ON public.settings USING btree (setting_type);


--
-- TOC entry 4117 (class 1259 OID 143556)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4120 (class 1259 OID 29770)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 4121 (class 1259 OID 29771)
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 4128 (class 1259 OID 29772)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4133 (class 1259 OID 29773)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 4129 (class 1259 OID 29774)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 4130 (class 1259 OID 29775)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 4140 (class 1259 OID 29776)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4141 (class 1259 OID 29777)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: supabase_functions_admin
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4216 (class 0 OID 0)
-- Name: messages_2024_12_23_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2024_12_23_pkey;


--
-- TOC entry 4217 (class 0 OID 0)
-- Name: messages_2024_12_24_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2024_12_24_pkey;


--
-- TOC entry 4218 (class 0 OID 0)
-- Name: messages_2024_12_25_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2024_12_25_pkey;


--
-- TOC entry 4219 (class 0 OID 0)
-- Name: messages_2024_12_26_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2024_12_26_pkey;


--
-- TOC entry 4220 (class 0 OID 0)
-- Name: messages_2024_12_27_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2024_12_27_pkey;


--
-- TOC entry 4249 (class 2620 OID 16923)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4250 (class 2620 OID 16924)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4221 (class 2606 OID 16926)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4222 (class 2606 OID 16931)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4223 (class 2606 OID 16936)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4224 (class 2606 OID 16941)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4225 (class 2606 OID 16946)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4226 (class 2606 OID 16951)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4227 (class 2606 OID 16956)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4228 (class 2606 OID 16961)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4229 (class 2606 OID 16966)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4230 (class 2606 OID 16971)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4231 (class 2606 OID 16976)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4239 (class 2606 OID 181222)
-- Name: campaign_leads campaign_leads_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_leads
    ADD CONSTRAINT campaign_leads_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id);


--
-- TOC entry 4240 (class 2606 OID 181227)
-- Name: campaign_leads campaign_leads_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_leads
    ADD CONSTRAINT campaign_leads_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- TOC entry 4248 (class 2606 OID 181415)
-- Name: campaign_metrics campaign_metrics_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaign_metrics
    ADD CONSTRAINT campaign_metrics_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id);


--
-- TOC entry 4236 (class 2606 OID 181177)
-- Name: campaigns campaigns_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 4242 (class 2606 OID 181258)
-- Name: email_campaigns email_campaigns_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id);


--
-- TOC entry 4243 (class 2606 OID 181263)
-- Name: email_campaigns email_campaigns_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- TOC entry 4244 (class 2606 OID 181268)
-- Name: email_campaigns email_campaigns_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.email_templates(id);


--
-- TOC entry 4238 (class 2606 OID 181207)
-- Name: email_templates email_templates_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id);


--
-- TOC entry 4237 (class 2606 OID 181192)
-- Name: knowledge_base knowledge_base_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 4245 (class 2606 OID 181283)
-- Name: lead_sources lead_sources_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT lead_sources_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- TOC entry 4246 (class 2606 OID 181288)
-- Name: lead_sources lead_sources_search_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT lead_sources_search_term_id_fkey FOREIGN KEY (search_term_id) REFERENCES public.search_terms(id);


--
-- TOC entry 4247 (class 2606 OID 181313)
-- Name: search_term_effectiveness search_term_effectiveness_search_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_term_effectiveness
    ADD CONSTRAINT search_term_effectiveness_search_term_id_fkey FOREIGN KEY (search_term_id) REFERENCES public.search_terms(id);


--
-- TOC entry 4241 (class 2606 OID 181242)
-- Name: search_terms search_terms_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_terms
    ADD CONSTRAINT search_terms_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id);


--
-- TOC entry 4232 (class 2606 OID 17121)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4233 (class 2606 OID 17126)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4234 (class 2606 OID 17131)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4235 (class 2606 OID 17136)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4400 (class 0 OID 29480)
-- Dependencies: 263
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4401 (class 0 OID 29486)
-- Dependencies: 264
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4402 (class 0 OID 29491)
-- Dependencies: 265
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4403 (class 0 OID 29498)
-- Dependencies: 266
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4404 (class 0 OID 29503)
-- Dependencies: 267
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4405 (class 0 OID 29508)
-- Dependencies: 268
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4406 (class 0 OID 29513)
-- Dependencies: 269
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4407 (class 0 OID 29518)
-- Dependencies: 270
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4408 (class 0 OID 29526)
-- Dependencies: 271
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4409 (class 0 OID 29532)
-- Dependencies: 273
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4410 (class 0 OID 29540)
-- Dependencies: 274
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4411 (class 0 OID 29546)
-- Dependencies: 275
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4412 (class 0 OID 29549)
-- Dependencies: 276
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4413 (class 0 OID 29554)
-- Dependencies: 277
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4414 (class 0 OID 29560)
-- Dependencies: 278
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4415 (class 0 OID 29566)
-- Dependencies: 279
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4421 (class 0 OID 104356)
-- Dependencies: 291
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4416 (class 0 OID 29605)
-- Dependencies: 283
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4417 (class 0 OID 29614)
-- Dependencies: 284
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4418 (class 0 OID 29618)
-- Dependencies: 285
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4419 (class 0 OID 29628)
-- Dependencies: 286
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4420 (class 0 OID 29635)
-- Dependencies: 287
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4422 (class 6104 OID 17485)
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- TOC entry 4504 (class 0 OID 0)
-- Dependencies: 4503
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- TOC entry 4505 (class 0 OID 0)
-- Dependencies: 18
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT ALL ON SCHEMA auth TO postgres;


--
-- TOC entry 4507 (class 0 OID 0)
-- Dependencies: 29
-- Name: SCHEMA cron; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA cron TO postgres WITH GRANT OPTION;


--
-- TOC entry 4508 (class 0 OID 0)
-- Dependencies: 21
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- TOC entry 4512 (class 0 OID 0)
-- Dependencies: 20
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- TOC entry 4513 (class 0 OID 0)
-- Dependencies: 17
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;
GRANT USAGE ON SCHEMA realtime TO postgres;


--
-- TOC entry 4514 (class 0 OID 0)
-- Dependencies: 19
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;
GRANT ALL ON SCHEMA storage TO postgres;


--
-- TOC entry 4515 (class 0 OID 0)
-- Dependencies: 22
-- Name: SCHEMA supabase_functions; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA supabase_functions TO anon;
GRANT USAGE ON SCHEMA supabase_functions TO authenticated;
GRANT USAGE ON SCHEMA supabase_functions TO service_role;
GRANT ALL ON SCHEMA supabase_functions TO supabase_functions_admin;
GRANT USAGE ON SCHEMA supabase_functions TO postgres;


--
-- TOC entry 4523 (class 0 OID 0)
-- Dependencies: 526
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;
GRANT ALL ON FUNCTION auth.email() TO postgres;


--
-- TOC entry 4524 (class 0 OID 0)
-- Dependencies: 527
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;
GRANT ALL ON FUNCTION auth.jwt() TO postgres;


--
-- TOC entry 4526 (class 0 OID 0)
-- Dependencies: 528
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;
GRANT ALL ON FUNCTION auth.role() TO postgres;


--
-- TOC entry 4528 (class 0 OID 0)
-- Dependencies: 529
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;
GRANT ALL ON FUNCTION auth.uid() TO postgres;


--
-- TOC entry 4529 (class 0 OID 0)
-- Dependencies: 601
-- Name: FUNCTION alter_job(job_id bigint, schedule text, command text, database text, username text, active boolean); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.alter_job(job_id bigint, schedule text, command text, database text, username text, active boolean) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4530 (class 0 OID 0)
-- Dependencies: 586
-- Name: FUNCTION job_cache_invalidate(); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.job_cache_invalidate() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4531 (class 0 OID 0)
-- Dependencies: 584
-- Name: FUNCTION schedule(schedule text, command text); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.schedule(schedule text, command text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4532 (class 0 OID 0)
-- Dependencies: 587
-- Name: FUNCTION schedule(job_name text, schedule text, command text); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.schedule(job_name text, schedule text, command text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4533 (class 0 OID 0)
-- Dependencies: 602
-- Name: FUNCTION schedule_in_database(job_name text, schedule text, command text, database text, username text, active boolean); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.schedule_in_database(job_name text, schedule text, command text, database text, username text, active boolean) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4534 (class 0 OID 0)
-- Dependencies: 585
-- Name: FUNCTION unschedule(job_id bigint); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.unschedule(job_id bigint) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4535 (class 0 OID 0)
-- Dependencies: 603
-- Name: FUNCTION unschedule(job_name text); Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON FUNCTION cron.unschedule(job_name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4536 (class 0 OID 0)
-- Dependencies: 530
-- Name: FUNCTION algorithm_sign(signables text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4537 (class 0 OID 0)
-- Dependencies: 344
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4538 (class 0 OID 0)
-- Dependencies: 531
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4539 (class 0 OID 0)
-- Dependencies: 532
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4540 (class 0 OID 0)
-- Dependencies: 533
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4541 (class 0 OID 0)
-- Dependencies: 534
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4542 (class 0 OID 0)
-- Dependencies: 535
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4543 (class 0 OID 0)
-- Dependencies: 536
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4544 (class 0 OID 0)
-- Dependencies: 537
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4545 (class 0 OID 0)
-- Dependencies: 538
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4546 (class 0 OID 0)
-- Dependencies: 539
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4547 (class 0 OID 0)
-- Dependencies: 540
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4548 (class 0 OID 0)
-- Dependencies: 541
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4549 (class 0 OID 0)
-- Dependencies: 542
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4550 (class 0 OID 0)
-- Dependencies: 543
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4552 (class 0 OID 0)
-- Dependencies: 545
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- TOC entry 4554 (class 0 OID 0)
-- Dependencies: 363
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4556 (class 0 OID 0)
-- Dependencies: 544
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- TOC entry 4557 (class 0 OID 0)
-- Dependencies: 365
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4558 (class 0 OID 0)
-- Dependencies: 366
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4559 (class 0 OID 0)
-- Dependencies: 364
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4560 (class 0 OID 0)
-- Dependencies: 546
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4561 (class 0 OID 0)
-- Dependencies: 523
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4562 (class 0 OID 0)
-- Dependencies: 368
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4563 (class 0 OID 0)
-- Dependencies: 369
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4564 (class 0 OID 0)
-- Dependencies: 370
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4565 (class 0 OID 0)
-- Dependencies: 371
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4566 (class 0 OID 0)
-- Dependencies: 372
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4567 (class 0 OID 0)
-- Dependencies: 373
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4568 (class 0 OID 0)
-- Dependencies: 374
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4569 (class 0 OID 0)
-- Dependencies: 375
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4570 (class 0 OID 0)
-- Dependencies: 376
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4571 (class 0 OID 0)
-- Dependencies: 377
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4572 (class 0 OID 0)
-- Dependencies: 378
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4573 (class 0 OID 0)
-- Dependencies: 547
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4574 (class 0 OID 0)
-- Dependencies: 379
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4575 (class 0 OID 0)
-- Dependencies: 380
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4576 (class 0 OID 0)
-- Dependencies: 381
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4577 (class 0 OID 0)
-- Dependencies: 548
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4578 (class 0 OID 0)
-- Dependencies: 382
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4579 (class 0 OID 0)
-- Dependencies: 383
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4580 (class 0 OID 0)
-- Dependencies: 384
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4581 (class 0 OID 0)
-- Dependencies: 347
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4582 (class 0 OID 0)
-- Dependencies: 507
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4583 (class 0 OID 0)
-- Dependencies: 367
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4585 (class 0 OID 0)
-- Dependencies: 549
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4586 (class 0 OID 0)
-- Dependencies: 387
-- Name: FUNCTION sign(payload json, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4587 (class 0 OID 0)
-- Dependencies: 388
-- Name: FUNCTION try_cast_double(inp text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4588 (class 0 OID 0)
-- Dependencies: 386
-- Name: FUNCTION url_decode(data text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.url_decode(data text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.url_decode(data text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4589 (class 0 OID 0)
-- Dependencies: 390
-- Name: FUNCTION url_encode(data bytea); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4590 (class 0 OID 0)
-- Dependencies: 392
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4591 (class 0 OID 0)
-- Dependencies: 391
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4592 (class 0 OID 0)
-- Dependencies: 389
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4593 (class 0 OID 0)
-- Dependencies: 393
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4594 (class 0 OID 0)
-- Dependencies: 394
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4595 (class 0 OID 0)
-- Dependencies: 396
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4596 (class 0 OID 0)
-- Dependencies: 395
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4597 (class 0 OID 0)
-- Dependencies: 398
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4598 (class 0 OID 0)
-- Dependencies: 399
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4599 (class 0 OID 0)
-- Dependencies: 400
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;


--
-- TOC entry 4600 (class 0 OID 0)
-- Dependencies: 550
-- Name: FUNCTION verify(token text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO dashboard_user;
GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO postgres WITH GRANT OPTION;


--
-- TOC entry 4601 (class 0 OID 0)
-- Dependencies: 598
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- TOC entry 4602 (class 0 OID 0)
-- Dependencies: 604
-- Name: FUNCTION http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;
GRANT ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;


--
-- TOC entry 4603 (class 0 OID 0)
-- Dependencies: 605
-- Name: FUNCTION http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer); Type: ACL; Schema: net; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO anon;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO authenticated;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO service_role;
GRANT ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO postgres;


--
-- TOC entry 4604 (class 0 OID 0)
-- Dependencies: 410
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: postgres
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- TOC entry 4605 (class 0 OID 0)
-- Dependencies: 566
-- Name: FUNCTION crypto_aead_det_decrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea); Type: ACL; Schema: pgsodium; Owner: pgsodium_keymaker
--

GRANT ALL ON FUNCTION pgsodium.crypto_aead_det_decrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea) TO service_role;


--
-- TOC entry 4606 (class 0 OID 0)
-- Dependencies: 568
-- Name: FUNCTION crypto_aead_det_encrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea); Type: ACL; Schema: pgsodium; Owner: pgsodium_keymaker
--

GRANT ALL ON FUNCTION pgsodium.crypto_aead_det_encrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea) TO service_role;


--
-- TOC entry 4607 (class 0 OID 0)
-- Dependencies: 570
-- Name: FUNCTION crypto_aead_det_keygen(); Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pgsodium.crypto_aead_det_keygen() TO service_role;


--
-- TOC entry 4608 (class 0 OID 0)
-- Dependencies: 563
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;


--
-- TOC entry 4609 (class 0 OID 0)
-- Dependencies: 508
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;


--
-- TOC entry 4610 (class 0 OID 0)
-- Dependencies: 564
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;


--
-- TOC entry 4611 (class 0 OID 0)
-- Dependencies: 582
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;


--
-- TOC entry 4612 (class 0 OID 0)
-- Dependencies: 583
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;


--
-- TOC entry 4613 (class 0 OID 0)
-- Dependencies: 589
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;


--
-- TOC entry 4614 (class 0 OID 0)
-- Dependencies: 588
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;


--
-- TOC entry 4615 (class 0 OID 0)
-- Dependencies: 590
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;


--
-- TOC entry 4616 (class 0 OID 0)
-- Dependencies: 510
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;


--
-- TOC entry 4617 (class 0 OID 0)
-- Dependencies: 591
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;


--
-- TOC entry 4618 (class 0 OID 0)
-- Dependencies: 515
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;


--
-- TOC entry 4619 (class 0 OID 0)
-- Dependencies: 516
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.topic() TO postgres;


--
-- TOC entry 4620 (class 0 OID 0)
-- Dependencies: 517
-- Name: FUNCTION can_insert_object(bucketid text, name text, owner uuid, metadata jsonb); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) TO postgres;


--
-- TOC entry 4621 (class 0 OID 0)
-- Dependencies: 518
-- Name: FUNCTION extension(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.extension(name text) TO postgres;


--
-- TOC entry 4622 (class 0 OID 0)
-- Dependencies: 511
-- Name: FUNCTION filename(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.filename(name text) TO postgres;


--
-- TOC entry 4623 (class 0 OID 0)
-- Dependencies: 512
-- Name: FUNCTION foldername(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.foldername(name text) TO postgres;


--
-- TOC entry 4624 (class 0 OID 0)
-- Dependencies: 513
-- Name: FUNCTION get_size_by_bucket(); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.get_size_by_bucket() TO postgres;


--
-- TOC entry 4625 (class 0 OID 0)
-- Dependencies: 514
-- Name: FUNCTION list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) TO postgres;


--
-- TOC entry 4626 (class 0 OID 0)
-- Dependencies: 592
-- Name: FUNCTION list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) TO postgres;


--
-- TOC entry 4627 (class 0 OID 0)
-- Dependencies: 519
-- Name: FUNCTION search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) TO postgres;


--
-- TOC entry 4628 (class 0 OID 0)
-- Dependencies: 524
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.update_updated_at_column() TO postgres;


--
-- TOC entry 4629 (class 0 OID 0)
-- Dependencies: 594
-- Name: FUNCTION http_request(); Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

REVOKE ALL ON FUNCTION supabase_functions.http_request() FROM PUBLIC;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO anon;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO authenticated;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO service_role;
GRANT ALL ON FUNCTION supabase_functions.http_request() TO postgres;


--
-- TOC entry 4631 (class 0 OID 0)
-- Dependencies: 263
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- TOC entry 4633 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.flow_state TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;


--
-- TOC entry 4636 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.identities TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;


--
-- TOC entry 4638 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- TOC entry 4640 (class 0 OID 0)
-- Dependencies: 267
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;


--
-- TOC entry 4642 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;


--
-- TOC entry 4644 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;


--
-- TOC entry 4645 (class 0 OID 0)
-- Dependencies: 270
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;


--
-- TOC entry 4647 (class 0 OID 0)
-- Dependencies: 271
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- TOC entry 4649 (class 0 OID 0)
-- Dependencies: 272
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- TOC entry 4651 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;


--
-- TOC entry 4653 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;


--
-- TOC entry 4655 (class 0 OID 0)
-- Dependencies: 275
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.schema_migrations TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.schema_migrations TO postgres;
GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- TOC entry 4658 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.sessions TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;


--
-- TOC entry 4660 (class 0 OID 0)
-- Dependencies: 277
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;


--
-- TOC entry 4663 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;


--
-- TOC entry 4666 (class 0 OID 0)
-- Dependencies: 279
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- TOC entry 4667 (class 0 OID 0)
-- Dependencies: 300
-- Name: TABLE job; Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT SELECT ON TABLE cron.job TO postgres WITH GRANT OPTION;


--
-- TOC entry 4668 (class 0 OID 0)
-- Dependencies: 302
-- Name: TABLE job_run_details; Type: ACL; Schema: cron; Owner: supabase_admin
--

GRANT ALL ON TABLE cron.job_run_details TO postgres WITH GRANT OPTION;


--
-- TOC entry 4669 (class 0 OID 0)
-- Dependencies: 257
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;


--
-- TOC entry 4670 (class 0 OID 0)
-- Dependencies: 256
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;


--
-- TOC entry 4671 (class 0 OID 0)
-- Dependencies: 255
-- Name: TABLE decrypted_key; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT ALL ON TABLE pgsodium.decrypted_key TO pgsodium_keyholder;


--
-- TOC entry 4672 (class 0 OID 0)
-- Dependencies: 253
-- Name: TABLE masking_rule; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT ALL ON TABLE pgsodium.masking_rule TO pgsodium_keyholder;


--
-- TOC entry 4673 (class 0 OID 0)
-- Dependencies: 254
-- Name: TABLE mask_columns; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT ALL ON TABLE pgsodium.mask_columns TO pgsodium_keyholder;


--
-- TOC entry 4694 (class 0 OID 0)
-- Dependencies: 291
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;
GRANT ALL ON TABLE realtime.messages TO postgres;


--
-- TOC entry 4695 (class 0 OID 0)
-- Dependencies: 292
-- Name: TABLE messages_2024_12_23; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2024_12_23 TO dashboard_user;
GRANT ALL ON TABLE realtime.messages_2024_12_23 TO postgres;


--
-- TOC entry 4696 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE messages_2024_12_24; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2024_12_24 TO dashboard_user;
GRANT ALL ON TABLE realtime.messages_2024_12_24 TO postgres;


--
-- TOC entry 4697 (class 0 OID 0)
-- Dependencies: 294
-- Name: TABLE messages_2024_12_25; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2024_12_25 TO dashboard_user;
GRANT ALL ON TABLE realtime.messages_2024_12_25 TO postgres;


--
-- TOC entry 4698 (class 0 OID 0)
-- Dependencies: 295
-- Name: TABLE messages_2024_12_26; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2024_12_26 TO dashboard_user;
GRANT ALL ON TABLE realtime.messages_2024_12_26 TO postgres;


--
-- TOC entry 4699 (class 0 OID 0)
-- Dependencies: 297
-- Name: TABLE messages_2024_12_27; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.messages_2024_12_27 TO dashboard_user;
GRANT ALL ON TABLE realtime.messages_2024_12_27 TO postgres;


--
-- TOC entry 4700 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;
GRANT ALL ON TABLE realtime.schema_migrations TO postgres;


--
-- TOC entry 4701 (class 0 OID 0)
-- Dependencies: 281
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;
GRANT ALL ON TABLE realtime.subscription TO postgres;


--
-- TOC entry 4702 (class 0 OID 0)
-- Dependencies: 282
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;


--
-- TOC entry 4704 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres;


--
-- TOC entry 4705 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE migrations; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.migrations TO anon;
GRANT ALL ON TABLE storage.migrations TO authenticated;
GRANT ALL ON TABLE storage.migrations TO service_role;
GRANT ALL ON TABLE storage.migrations TO postgres;


--
-- TOC entry 4707 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres;


--
-- TOC entry 4708 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;
GRANT ALL ON TABLE storage.s3_multipart_uploads TO postgres;


--
-- TOC entry 4709 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;
GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO postgres;


--
-- TOC entry 4711 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE hooks; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.hooks TO anon;
GRANT ALL ON TABLE supabase_functions.hooks TO authenticated;
GRANT ALL ON TABLE supabase_functions.hooks TO service_role;
GRANT ALL ON TABLE supabase_functions.hooks TO postgres;


--
-- TOC entry 4713 (class 0 OID 0)
-- Dependencies: 289
-- Name: SEQUENCE hooks_id_seq; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO anon;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO authenticated;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO service_role;
GRANT ALL ON SEQUENCE supabase_functions.hooks_id_seq TO postgres;


--
-- TOC entry 4714 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE migrations; Type: ACL; Schema: supabase_functions; Owner: supabase_functions_admin
--

GRANT ALL ON TABLE supabase_functions.migrations TO anon;
GRANT ALL ON TABLE supabase_functions.migrations TO authenticated;
GRANT ALL ON TABLE supabase_functions.migrations TO service_role;
GRANT ALL ON TABLE supabase_functions.migrations TO postgres;


--
-- TOC entry 2680 (class 826 OID 17493)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES  TO dashboard_user;


--
-- TOC entry 2681 (class 826 OID 17494)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO dashboard_user;


--
-- TOC entry 2682 (class 826 OID 17495)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES  TO dashboard_user;


--
-- TOC entry 2706 (class 826 OID 176318)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: cron; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA cron GRANT ALL ON SEQUENCES  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2708 (class 826 OID 176317)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: cron; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA cron GRANT ALL ON FUNCTIONS  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2707 (class 826 OID 176316)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: cron; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA cron GRANT ALL ON TABLES  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2683 (class 826 OID 17496)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2684 (class 826 OID 17497)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2685 (class 826 OID 17498)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES  TO postgres WITH GRANT OPTION;


--
-- TOC entry 2705 (class 826 OID 17499)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2704 (class 826 OID 17500)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2703 (class 826 OID 17501)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2686 (class 826 OID 17502)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2687 (class 826 OID 17503)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2688 (class 826 OID 17504)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2689 (class 826 OID 17505)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgsodium; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium GRANT ALL ON SEQUENCES  TO pgsodium_keyholder;


--
-- TOC entry 2690 (class 826 OID 17506)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgsodium; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium GRANT ALL ON TABLES  TO pgsodium_keyholder;


--
-- TOC entry 2691 (class 826 OID 17507)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON SEQUENCES  TO pgsodium_keyiduser;


--
-- TOC entry 2692 (class 826 OID 17508)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON FUNCTIONS  TO pgsodium_keyiduser;


--
-- TOC entry 2693 (class 826 OID 17509)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON TABLES  TO pgsodium_keyiduser;


--
-- TOC entry 2694 (class 826 OID 17512)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES  TO dashboard_user;


--
-- TOC entry 2695 (class 826 OID 17513)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS  TO dashboard_user;


--
-- TOC entry 2696 (class 826 OID 17514)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES  TO dashboard_user;


--
-- TOC entry 2697 (class 826 OID 17515)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2698 (class 826 OID 17516)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2699 (class 826 OID 17517)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 2700 (class 826 OID 17518)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON SEQUENCES  TO service_role;


--
-- TOC entry 2701 (class 826 OID 17519)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON FUNCTIONS  TO service_role;


--
-- TOC entry 2702 (class 826 OID 17520)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: supabase_functions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA supabase_functions GRANT ALL ON TABLES  TO service_role;


--
-- TOC entry 3873 (class 3466 OID 17521)
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- TOC entry 3874 (class 3466 OID 17522)
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- TOC entry 3875 (class 3466 OID 17523)
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- TOC entry 3876 (class 3466 OID 17524)
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO postgres;

--
-- TOC entry 3877 (class 3466 OID 17525)
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- TOC entry 3878 (class 3466 OID 17526)
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

-- Completed on 2025-01-06 14:27:06 CET

--
-- PostgreSQL database dump complete
--

-- Completed on 2025-01-06 14:27:06 CET

--
-- PostgreSQL database cluster dump complete
--

